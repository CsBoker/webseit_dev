<?php
require_once 'config/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isLoggedIn()) {
    header("Location: login.php?redirect=checkout.php");
    exit();
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: cart.php");
    exit();
}

$pdo = getDB();
$userId = $_SESSION['user_id'];

$error = null;

// If POST: process the checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read address selected by the user (e.g. from a <select name="id_address">)
    $idAddress = isset($_POST['id_address']) ? (int)$_POST['id_address'] : null;
    $addr = null;

    try {
        // Validate user owns the address
        if ($idAddress) {
            $stmtAddr = $pdo->prepare("
                SELECT a.address1, a.zip, a.city
                FROM Account_Address aa
                JOIN Address a ON a.id_address = aa.id_address
                WHERE aa.id_account = ? AND aa.id_address = ?
                LIMIT 1
            ");
            $stmtAddr->execute([$userId, $idAddress]);
            $addr = $stmtAddr->fetch(PDO::FETCH_ASSOC);
        }

        if (!$addr) {
            // Either no address selected or not owned by this user
            $error = "Please select a valid shipping address.";
            // Fall through to render the form again (GET-like behavior below)
        } else {
            // Human-readable snapshot saved with the order for audit/history:
            $shipping_snapshot = trim(($addr['address1'] ?? '') . ', ' . ($addr['zip'] ?? '') . ' ' . ($addr['city'] ?? ''));

            $pdo->beginTransaction();

            // 1) Insert order
            $stmt = $pdo->prepare("
                INSERT INTO Orders (date_order, shipping_address, id_address, last_changed, id_account, id_order_status) 
                VALUES (NOW(), :shipping_address, :id_address, NOW(), :id_account, 1)
            ");
            $stmt->execute([
                ':shipping_address' => $shipping_snapshot,
                ':id_address'       => $idAddress,
                ':id_account'       => $userId
            ]);
            $orderId = $pdo->lastInsertId();

            // 2) Insert order items
            foreach ($cart as $id_book => $qty) {
                $stmtDetails = $pdo->prepare("
                    INSERT INTO OrderDetails (id_order, id_book, item_count) 
                    VALUES (:id_order, :id_book, :qty)
                ");
                $stmtDetails->execute([
                    ':id_order' => $orderId,
                    ':id_book'  => $id_book,
                    ':qty'      => $qty
                ]);
            }

            $pdo->commit();

            // 3) Clear cart and redirect
            unset($_SESSION['cart']);
            header("Location: orders.php?success=1");
            exit();
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = "Checkout failed: " . htmlspecialchars($e->getMessage());
    }
}

// If GET or POST with error: fetch addresses to display the form
$rows = $pdo->prepare("
  SELECT a.id_address,
         CONCAT(a.address1, ', ', a.zip, ' ', a.city) AS label,
         aa.is_default
  FROM Account_Address aa
  JOIN Address a ON a.id_address = aa.id_address
  WHERE aa.id_account = ?
  ORDER BY aa.is_default DESC, label ASC
");
$rows->execute([$userId]);
$addresses = $rows->fetchAll(PDO::FETCH_ASSOC);

// Preserve previously posted selection if any
$postedId = isset($_POST['id_address']) ? (int)$_POST['id_address'] : null;
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Checkout</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 24px; }
    .container { max-width: 680px; margin: 0 auto; }
    .card { border: 1px solid #ddd; border-radius: 8px; padding: 16px; }
    .row { margin-bottom: 12px; }
    label { display: block; margin-bottom: 6px; font-weight: 600; }
    select, button { padding: 10px; font-size: 16px; }
    .error { color: #b00020; background: #fde7ea; border: 1px solid #f5c2c7; padding: 10px; border-radius: 6px; margin-bottom: 12px; }
    .empty { color: #555; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Checkout</h1>

    <?php if ($error): ?>
      <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <div class="card">
      <?php if (empty($addresses)): ?>
        <p class="empty">No saved addresses yet.</p>
        <p><a href="address_add.php">Add a new address</a> and return here to complete checkout.</p>
      <?php else: ?>
        <form method="post" action="checkout.php">
          <div class="row">
            <label for="id_address">Shipping address</label>
            <select id="id_address" name="id_address" required>
              <option value="" disabled <?= $postedId ? '' : 'selected' ?>>Select an address…</option>
              <?php foreach ($addresses as $ad): ?>
                <?php
                  $selected = $postedId
                    ? ((int)$postedId === (int)$ad['id_address'])
                    : ((int)$ad['is_default'] === 1);
                ?>
                <option value="<?= (int)$ad['id_address'] ?>" <?= $selected ? 'selected' : '' ?>>
                  <?= htmlspecialchars($ad['label']) ?><?= ((int)$ad['is_default'] === 1) ? ' (default)' : '' ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <button type="submit">Place order</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
