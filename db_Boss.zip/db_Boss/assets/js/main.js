// BOSS - Main JavaScript File

document.addEventListener("DOMContentLoaded", () => {
  // Initialize the application
  initializeApp()
})

function initializeApp() {
  loadFeaturedBooks()
  loadCategories()
  setupSearch()
  setupCart()
}

// Load featured books on homepage
function loadFeaturedBooks() {
  const featuredBooksContainer = document.getElementById("featuredBooks")
  if (!featuredBooksContainer) return

  fetch("api/books.php?action=featured")
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        displayBooks(data.books, featuredBooksContainer)
      }
    })
    .catch((error) => console.error("Error loading featured books:", error))
}

// Load categories
function loadCategories() {
  const categoriesContainer = document.getElementById("categoriesGrid")
  if (!categoriesContainer) return

  fetch("api/categories.php?action=all")
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        displayCategories(data.categories, categoriesContainer)
      }
    })
    .catch((error) => console.error("Error loading categories:", error))
}

// Display books in grid
function displayBooks(books, container) {
  container.innerHTML = ""

  books.forEach((book) => {
    const bookCard = createBookCard(book)
    container.appendChild(bookCard)
  })
}

// Create book card element
function createBookCard(book) {
  const card = document.createElement("div")
  card.className = "book-card"

  card.innerHTML = `
        <div class="book-image">
            <i class="fas fa-book"></i>
        </div>
        <div class="book-info">
            <h4 class="book-title">${book.title}</h4>
            <p class="book-author">by ${book.authors || "Unknown Author"}</p>
            <p class="book-price">$${Number.parseFloat(book.price).toFixed(2)}</p>
            <button class="btn btn-primary" onclick="addToCart(${book.id_book})">
                <i class="fas fa-cart-plus"></i> Add to Cart
            </button>
        </div>
    `

  return card
}

// Display categories
function displayCategories(categories, container) {
  container.innerHTML = ""

  const categoryIcons = {
    Fiction: "fas fa-book-open",
    "Non-fiction": "fas fa-newspaper",
    Science: "fas fa-flask",
    Fantasy: "fas fa-dragon",
    History: "fas fa-landmark",
    Biography: "fas fa-user",
    Children: "fas fa-child",
    Mystery: "fas fa-search",
    Romance: "fas fa-heart",
    Horror: "fas fa-ghost",
  }

  categories.slice(0, 8).forEach((category) => {
    const categoryCard = document.createElement("a")
    categoryCard.href = `books.php?category=${category.id_category}`
    categoryCard.className = "category-card"

    const iconClass = categoryIcons[category.category_name] || "fas fa-book"

    categoryCard.innerHTML = `
            <i class="${iconClass}"></i>
            <h4>${category.category_name}</h4>
            <p>${category.book_count} books</p>
        `

    container.appendChild(categoryCard)
  })
}

// Setup search functionality
function setupSearch() {
  const searchInput = document.getElementById("searchInput")
  if (!searchInput) return

  // Define a helper that performs the navigation.  If the search box is
  // empty we simply redirect to the books listing; otherwise we include
  // the encoded query as a parameter.
  const go = () => {
    const query = searchInput.value.trim()
    if (query) {
      window.location.href = `books.php?search=${encodeURIComponent(query)}`
    } else {
      window.location.href = `books.php`
    }
  }

  // Trigger search when the user presses Enter in the input field
  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") go()
  })

  // Locate the button within the search box using a more robust selector
  // instead of relying on nextElementSibling.  This allows us to change
  // the DOM structure or CSS ordering without breaking the event binding.
  const searchButton = document.querySelector(".search-box button")
  if (searchButton) {
    searchButton.addEventListener("click", go)
  }
}

// Setup cart functionality
function setupCart() {
  updateCartCount()
}

// Add item to cart
function addToCart(bookId) {
  const cart = getCart()

  if (cart[bookId]) {
    cart[bookId]++
  } else {
    cart[bookId] = 1
  }

  saveCart(cart)
  updateCartCount()
  showNotification("Book added to cart!", "success")
}

// Remove item from cart
function removeFromCart(bookId) {
  const cart = getCart()
  delete cart[bookId]
  saveCart(cart)
  updateCartCount()
  showNotification("Book removed from cart!", "info")
}

// Update cart item quantity
function updateCartQuantity(bookId, quantity) {
  const cart = getCart()

  if (quantity <= 0) {
    delete cart[bookId]
  } else {
    cart[bookId] = quantity
  }

  saveCart(cart)
  updateCartCount()
}

// Get cart from localStorage
function getCart() {
  const cart = localStorage.getItem("boss_cart")
  return cart ? JSON.parse(cart) : {}
}

// Save cart to localStorage
function saveCart(cart) {
  localStorage.setItem("boss_cart", JSON.stringify(cart))
}

// Update cart count display
function updateCartCount() {
  const cart = getCart()
  const count = Object.values(cart).reduce((sum, qty) => sum + qty, 0)

  const cartCountElement = document.querySelector(".cart-count")
  if (cartCountElement) {
    cartCountElement.textContent = count
  }
}
