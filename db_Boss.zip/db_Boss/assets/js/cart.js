// Cart-specific JavaScript functionality

// Retrieve the cart from localStorage.  We re‑use the same key as
// main.js ("boss_cart") so that items added on the home/books pages
// are visible here.
function getCart() {
  const cart = localStorage.getItem("boss_cart")
  return cart ? JSON.parse(cart) : {}
}

// Persist the cart to localStorage under the unified key
function saveCart(cart) {
  localStorage.setItem("boss_cart", JSON.stringify(cart))
}

// Update the visual cart count in the header.  We select the
// element with the class "cart-count" which is shared across pages.
function updateCartCount() {
  const cart = getCart()
  const count = Object.values(cart).reduce((sum, qty) => sum + qty, 0)
  const cartCountElement = document.querySelector(".cart-count")
  if (cartCountElement) {
    cartCountElement.textContent = count
  }
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartCount()
  loadCartPage()
})

// Load cart page content
function loadCartPage() {
  const cart = getCart()
  const cartItemsContainer = document.getElementById("cartItems")
  const cartSummaryContainer = document.getElementById("cartSummary")
  const emptyCartContainer = document.getElementById("emptyCart")

  if (Object.keys(cart).length === 0) {
    cartItemsContainer.style.display = "none"
    cartSummaryContainer.style.display = "none"
    emptyCartContainer.style.display = "block"
    return
  }

  // Load cart items
  loadCartItems(cart)
}

// Load cart items with book details
function loadCartItems(cart) {
  const bookIds = Object.keys(cart)

  // Fetch book details for all items in cart
  fetch("api/books.php?action=multiple&ids=" + bookIds.join(","))
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        displayCartItems(data.books, cart)
        displayCartSummary(data.books, cart)
      }
    })
    .catch((error) => console.error("Error loading cart items:", error))
}

// Display cart items
function displayCartItems(books, cart) {
  const container = document.getElementById("cartItems")
  container.innerHTML = ""

  books.forEach((book) => {
    const quantity = cart[book.id_book]
    const itemTotal = book.price * quantity

    const cartItem = document.createElement("div")
    cartItem.className = "cart-item"
    cartItem.innerHTML = `
            <div class="cart-item-image">
                <i class="fas fa-book"></i>
            </div>
            <div class="cart-item-details">
                <h4>${book.title}</h4>
                <p>by ${book.authors || "Unknown Author"}</p>
                <p class="item-price">$${Number.parseFloat(book.price).toFixed(2)} each</p>
            </div>
            <div class="cart-item-quantity">
                <button onclick="updateCartQuantity(${book.id_book}, ${quantity - 1})" class="qty-btn">-</button>
                <span class="quantity">${quantity}</span>
                <button onclick="updateCartQuantity(${book.id_book}, ${quantity + 1})" class="qty-btn">+</button>
            </div>
            <div class="cart-item-total">
                <p class="item-total">$${itemTotal.toFixed(2)}</p>
                <button onclick="removeFromCart(${book.id_book}); loadCartPage();" class="remove-btn">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `

    container.appendChild(cartItem)
  })
}

// Display cart summary
function displayCartSummary(books, cart) {
  const container = document.getElementById("cartSummary")

  let subtotal = 0
  let totalItems = 0

  books.forEach((book) => {
    const quantity = cart[book.id_book]
    subtotal += book.price * quantity
    totalItems += quantity
  })

  const shipping = subtotal > 50 ? 0 : 5.99
  const total = subtotal + shipping

  container.innerHTML = `
        <div class="summary-card">
            <h3>Order Summary</h3>
            <div class="summary-line">
                <span>Items (${totalItems})</span>
                <span>$${subtotal.toFixed(2)}</span>
            </div>
            <div class="summary-line">
                <span>Shipping</span>
                <span>${shipping === 0 ? "FREE" : "$" + shipping.toFixed(2)}</span>
            </div>
            <div class="summary-line total">
                <span>Total</span>
                <span>$${total.toFixed(2)}</span>
            </div>
            ${shipping > 0 ? '<p class="shipping-note">Free shipping on orders over $50</p>' : ""}
            <button class="btn btn-primary btn-full" onclick="proceedToCheckout()">
                <i class="fas fa-credit-card"></i> Proceed to Checkout
            </button>
            <button class="btn btn-full" onclick="clearCart(); loadCartPage();">
                <i class="fas fa-trash"></i> Clear Cart
            </button>
        </div>
    `
}

// Proceed to checkout
function proceedToCheckout() {
  // Check if user is logged in
  fetch("api/auth.php?action=check")
    .then((response) => response.json())
    .then((data) => {
      if (data.loggedIn) {
        window.location.href = "checkout.php"
      } else {
        if (confirm("You need to login to proceed with checkout. Would you like to login now?")) {
          window.location.href = "login.php?redirect=checkout.php"
        }
      }
    })
    .catch((error) => {
      console.error("Error checking auth status:", error)
      window.location.href = "login.php?redirect=checkout.php"
    })
}

// Update cart quantity and reload page
function updateCartQuantity(bookId, quantity) {
  const cart = getCart()

  if (quantity <= 0) {
    delete cart[bookId]
  } else {
    cart[bookId] = quantity
  }

  saveCart(cart)
  updateCartCount()
  loadCartPage()
}

// Remove item from cart
function removeFromCart(bookId) {
  const cart = getCart()
  delete cart[bookId]
  saveCart(cart)
  updateCartCount()
}

// Clear cart
function clearCart() {
  localStorage.removeItem("boss_cart")
  updateCartCount()
}
