<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$id_book = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id_book > 0 && isset($_SESSION['cart'][$id_book])) {
    unset($_SESSION['cart'][$id_book]);
}

// Sepete geri yönlendir
header("Location: cart.php");
exit;