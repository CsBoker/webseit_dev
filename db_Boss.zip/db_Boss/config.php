<?php
// config.php — database configuration for BOSS
// Adjust credentials to match your local setup.

// Start session only once
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Site base URL (adjust if your folder name changes)
define('BASE_URL', '/db_Boss_upd/db_Boss/');

// Database credentials
$DB_HOST = getenv('DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('DB_NAME') ?: 'db_boss';
$DB_USER = getenv('DB_USER') ?: 'root';
$DB_PASS = getenv('DB_PASS') ?: '';

$dsn = "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4";

// Create PDO connection
try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo "Database connection failed: " . htmlspecialchars($e->getMessage());
    exit;
}

// ✅ Helper function: always return PDO connection
function getDB() {
    return $GLOBALS['pdo'];
}
?>