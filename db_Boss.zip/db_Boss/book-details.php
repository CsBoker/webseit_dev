<?php 
require_once 'config/config.php';

$bookModel = new Book();
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: books.php');
    exit();
}

$book = $bookModel->getBookDetails($id);

if (!$book) {
    header('Location: books.php');
    exit();
}

// Get related books from same category
$relatedBooks = [];
if ($book['id_category']) {
    $relatedBooks = $bookModel->getAllBooks(4, 0, $book['id_category']);
    // Remove current book from related books
    $relatedBooks = array_filter($relatedBooks, function($relatedBook) use ($id) {
        return $relatedBook['id_book'] != $id;
    });
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($book['title']); ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <!-- Breadcrumb -->
            <nav class="breadcrumb">
                <a href="index.php">Home</a>
                <span>/</span>
                <a href="books.php">Books</a>
                <?php if ($book['category_name']): ?>
                    <span>/</span>
                    <a href="books.php?category=<?php echo $book['id_category']; ?>">
                        <?php echo htmlspecialchars($book['category_name']); ?>
                    </a>
                <?php endif; ?>
                <span>/</span>
                <span><?php echo htmlspecialchars($book['title']); ?></span>
            </nav>

            <!-- Book Details -->
            <div class="book-details-container">
                <div class="book-details-image">
                    <div class="book-cover">
                        <?php if (!empty($book['image']) && file_exists(__DIR__ . '/images/books/' . $book['image'])): ?>
                            <img src="images/books/<?php echo htmlspecialchars($book['image']); ?>" alt="Cover of <?php echo htmlspecialchars($book['title']); ?>">
                        <?php else: ?>
                            <img src="images/books/default.jpg" alt="No cover available">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="book-details-info">
                    <h1 class="book-title"><?php echo htmlspecialchars($book['title']); ?></h1>
                    
                    <?php if ($book['authors']): ?>
                        <p class="book-authors">
                            <i class="fas fa-user"></i>
                            by <?php echo htmlspecialchars($book['authors']); ?>
                        </p>
                    <?php endif; ?>

                    <div class="book-meta">
                        <?php if ($book['category_name']): ?>
                            <span class="meta-item">
                                <i class="fas fa-tag"></i>
                                <a href="books.php?category=<?php echo $book['id_category']; ?>">
                                    <?php echo htmlspecialchars($book['category_name']); ?>
                                </a>
                            </span>
                        <?php endif; ?>

                        <?php if ($book['publisher_name']): ?>
                            <span class="meta-item">
                                <i class="fas fa-building"></i>
                                <?php echo htmlspecialchars($book['publisher_name']); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ($book['language_name']): ?>
                            <span class="meta-item">
                                <i class="fas fa-globe"></i>
                                <label for="languageSelect" style="font-weight: bold;">Language:</label>
                                <select id="languageSelect" onchange="changeLanguage()">
                                    <option value="original"
                                            data-title="<?php echo htmlspecialchars($book['title']); ?>"
                                            data-info="<?php echo htmlspecialchars($book['info']); ?>">
                                        <?php echo htmlspecialchars($book['language_name']); ?> (Original)
                                    </option>
                                    <?php if (!empty($book['translations'])): ?>
                                        <?php
                                            $translations = explode('||', $book['translations']);
                                            foreach ($translations as $t):
                                                list($langId, $langName, $translatedTitle) = explode(':', $t);
                                        ?>
                                            <option value="<?php echo $langId; ?>"
                                                    data-title="<?php echo htmlspecialchars($translatedTitle); ?>"
                                                    data-info="<?php echo htmlspecialchars($book['info']); ?>">
                                                <?php echo htmlspecialchars($langName); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </span>
                        <?php endif; ?>

                        <?php if ($book['isbn']): ?>
                            <span class="meta-item">
                                <i class="fas fa-barcode"></i>
                                ISBN: <?php echo htmlspecialchars($book['isbn']); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ($book['published']): ?>
                            <span class="meta-item">
                                <i class="fas fa-calendar"></i>
                                Published: <?php echo date('F j, Y', strtotime($book['published'])); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ($book['edition']): ?>
                            <span class="meta-item">
                                <i class="fas fa-bookmark"></i>
                                Edition: <?php echo $book['edition']; ?>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="book-pricing">
                        <div class="price-section">
                            <span class="current-price">$<?php echo number_format($book['price'], 2); ?></span>
                            <?php if ($book['is_in_stock'] && $book['amount'] > 0): ?>
                                <span class="stock-status in-stock">
                                    <i class="fas fa-check-circle"></i>
                                    In Stock (<?php echo $book['amount']; ?> available)
                                </span>
                            <?php else: ?>
                                <span class="stock-status out-of-stock">
                                    <i class="fas fa-times-circle"></i>
                                    Out of Stock
                                </span>
                            <?php endif; ?>
                        </div>

                        <?php if ($book['is_in_stock'] && $book['amount'] > 0): ?>
                            <div class="purchase-actions">
                                <button class="btn btn-primary btn-large" onclick="addToCart(<?php echo $book['id_book']; ?>)">
                                    <i class="fas fa-cart-plus"></i>
                                    Add to Cart
                                </button>
                                <button class="btn btn-secondary btn-large" onclick="buyNow(<?php echo $book['id_book']; ?>)">
                                    <i class="fas fa-bolt"></i>
                                    Buy Now
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($book['info']): ?>
                        <div class="book-description">
                            <h3>Description</h3>
                            <p><?php echo nl2br(htmlspecialchars($book['info'])); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

           <!-- Related Books -->
<?php if (!empty($relatedBooks)): ?>
    <section class="related-books">
        <h3>More books in <?php echo htmlspecialchars($book['category_name']); ?></h3>
        <div class="books-grid">
            <?php foreach (array_slice($relatedBooks, 0, 4) as $relatedBook): ?>
                <div class="book-card">
                    <div class="book-details-image">
                        <div class="book-cover">
                            <?php 
                            $imagePath = 'images/books/' . $relatedBook['image'];
                            $fullPath = __DIR__ . '/' . $imagePath;
                            if (!empty($relatedBook['image']) && file_exists($fullPath)): ?>
                                <img src="<?php echo $imagePath; ?>" alt="Cover of <?php echo htmlspecialchars($relatedBook['title']); ?>">
                            <?php else: ?>
                                <img src="images/books/default.jpg" alt="No cover available">
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="book-info">
                        <h4 class="book-title">
                            <a href="book-details.php?id=<?php echo $relatedBook['id_book']; ?>">
                                <?php echo htmlspecialchars($relatedBook['title']); ?>
                            </a>
                        </h4>
                        <p class="book-author">by <?php echo htmlspecialchars($relatedBook['authors'] ?: 'Unknown Author'); ?></p>
                        <p class="book-price">$<?php echo number_format($relatedBook['price'], 2); ?></p>
                        <div class="book-actions">
                            <button class="btn btn-primary" onclick="addToCart(<?php echo $relatedBook['id_book']; ?>)">
                                <i class="fas fa-cart-plus"></i> Add to Cart
                            </button>
                            <a href="book-details.php?id=<?php echo $relatedBook['id_book']; ?>" class="btn">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
    <script>
        function buyNow(bookId) {
            addToCart(bookId);
            setTimeout(() => {
                window.location.href = 'checkout.php';
            }, 500);
        }
    </script>
    <script>
        // Handle language change on the book details page.  When the user selects
        // a different language, update the title and description on the page
        // based on the data attributes on the option elements.  The original
        // language and description are stored on the "original" option.
        function changeLanguage() {
            const select = document.getElementById('languageSelect');
            const selected = select.options[select.selectedIndex];
            const newTitle = selected.getAttribute('data-title');
            const newInfo = selected.getAttribute('data-info');

            // Update the book title heading
            const titleEl = document.querySelector('.book-title');
            if (titleEl && newTitle) {
                titleEl.textContent = newTitle;
            }

            // Update the description paragraph, if it exists
            const descPara = document.querySelector('.book-description p');
            if (descPara && newInfo) {
                // If the description contained newlines originally, restore them
                descPara.textContent = newInfo;
            }
        }
    </script>
</body>
</html>