<?php
// login_process.php — authenticate against BOSS schema (Account + AccountRole)
require __DIR__ . '/config.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$email = trim($_POST['email'] ?? '');
$password = (string)($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    header("Location: /login.php?e=invalid");
    exit();
}

// Fetch account with role and type names (may be NULL)
$sql = <<<SQL
SELECT a.id_account, a.password_hash, COALESCE(LOWER(ar.role_name), '') AS role_name, COALESCE(LOWER(at.type_name), '') AS type_name
FROM Account a
LEFT JOIN AccountRole ar ON a.id_role = ar.id_role
LEFT JOIN AccountType at ON a.id_type = at.id_type
WHERE a.email = :email
LIMIT 1
SQL;

$stmt = $pdo->prepare($sql);
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: /login.php?e=invalid"); exit();
}

// Support legacy SHA2(...) hashes as present in db_boss_merged.sql inserts,
// but also support modern password_hash() rows if you later migrate.
$stored = (string)$user['password_hash'];
$ok = false;
if ($stored and str_starts_with($stored, '$')) {
    // bcrypt/argon2-style hash stored, use password_verify
    $ok = password_verify($password, $stored);
} else {
    // Compare sha256 hex of submitted password with stored
    $ok = (hash('sha256', $password) === strtolower($stored));
}

if (!$ok) {
    header("Location: /login.php?e=invalid"); exit();
}

// Normalize role to one of: admin, employee, customer.
// We try AccountRole first; if not present, infer from AccountType; else default to customer.
$role = 'customer';
$role_name = strtolower($user['role_name'] ?? '');
$type_name = strtolower($user['type_name'] ?? '');

if (in_array($role_name, ['admin'], true)) {
    $role = 'admin';
} elseif (in_array($role_name, ['employee', 'manager', 'staff'], true)) {
    $role = 'employee';
} elseif (in_array($role_name, ['buyer','reader'], true)) {
    $role = 'customer';
} elseif (in_array($type_name, ['admin'], true)) {
    $role = 'admin';
} elseif (in_array($type_name, ['employee'], true)) {
    $role = 'employee';
} else {
    $role = 'customer';
}

// Set session and redirect
$_SESSION['user_id'] = (int)$user['id_account'];
$_SESSION['role'] = $role;
$_SESSION['email'] = $email;

if ($role === 'admin') {
    header("Location: /admin_dashboard.php");
} elseif ($role === 'employee') {
    header("Location: /employee_dashboard.php");
} else {
    header("Location: /customer_dashboard.php");
}
exit;
?>
