<?php 
require_once 'config/config.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="container">
            <div class="hero-content">
                <h2>Discover Your Next Great Read</h2>
                <p>Browse thousands of books from top authors and publishers</p>
                <div class="hero-stats">
                    <?php
                    $bookCount = 0;
                    $authorCount = 0;
                    try {
                        $bookModel = new Book();
                        $authorModel = new Author();
                        $bookCount = $bookModel->getTotalBooks();
                        $authorCount = $authorModel->getTotalAuthors();
                    } catch (Exception $e) {}
                    ?>
                    <div class="stat">
                        <i class="fas fa-book"></i>
                        <span><?php echo number_format($bookCount); ?> Books</span>
                    </div>
                    <div class="stat">
                        <i class="fas fa-users"></i>
                        <span><?php echo number_format($authorCount); ?> Authors</span>
                    </div>
                    <div class="stat">
                        <i class="fas fa-star"></i>
                        <span>Rated 4.8/5</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Books -->
    <section class="featured-books" id="books">
        <div class="container">
            <h3>Featured Books</h3>
            <div class="books-grid">
                <?php
                try {
                    $bookModel = new Book();
                    $featuredBooks = $bookModel->getAllBooks(4, 0); // 4 kitap getir

                    foreach ($featuredBooks as $book) {
                        $imageFile = !empty($book['image']) ? $book['image'] : 'default.jpg';
                        $webPath   = "images/books/" . $imageFile;
                        ?>
                        <div class="book-card">
                            <div class="book-image">
                                <img src="<?php echo $webPath; ?>" 
                                     alt="<?php echo htmlspecialchars($book['title']); ?>" 
                                     class="book-cover">
                            </div>
                            <div class="book-info">
                                <h4 class="book-title"><?php echo htmlspecialchars($book['title']); ?></h4>
                                <p class="book-author">by <?php echo htmlspecialchars($book['authors'] ?: 'Unknown Author'); ?></p>
                                <p class="book-price">€<?php echo number_format($book['price'], 2); ?></p>
                                <div class="book-actions">
                                    <a href="book-details.php?id=<?php echo $book['id_book']; ?>" class="btn">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php }
                } catch (Exception $e) {
                    echo "<p>No featured books available right now.</p>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Categories -->
    <section class="categories" id="categories">
        <div class="container">
            <h3>Browse by Category</h3>
            <div class="categories-grid">
                <?php
                try {
                    $categoryModel = new Category();
                    $categories = $categoryModel->getAllCategories();

                    foreach ($categories as $cat) { ?>
                        <div class="category-card">
                            <h4><?php echo htmlspecialchars($cat['category_name']); ?></h4>
                            <p><?php echo (int)$cat['book_count']; ?> books</p>
                            <a href="books.php?category=<?php echo $cat['id_category']; ?>" class="btn">View</a>
                        </div>
                    <?php }
                } catch (Exception $e) {
                    echo "<p>No categories available.</p>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>

    <script src="assets/js/main.js"></script>
</body>
</html>