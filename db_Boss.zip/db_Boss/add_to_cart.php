<?php
require_once 'config/config.php';

// Sepeti session’da tut
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_book = (int) ($_POST['id_book'] ?? 0);
    $qty     = (int) ($_POST['qty'] ?? 1);

    if ($id_book > 0 && $qty > 0) {
        // Eğer sepet boşsa başlat
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Eğer kitap zaten varsa, miktarı artır
        if (isset($_SESSION['cart'][$id_book])) {
            $_SESSION['cart'][$id_book] += $qty;
        } else {
            $_SESSION['cart'][$id_book] = $qty;
        }
    }

    // Kitaplar sayfasına geri yönlendir
    header("Location: cart.php");
    exit;
}