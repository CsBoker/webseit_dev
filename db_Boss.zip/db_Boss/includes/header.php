<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kullanıcının rolünü belirle
$role = '';
if (!empty($_SESSION['role'])) {
    $role = strtolower($_SESSION['role']);
} elseif (!empty($_SESSION['user_role'])) {
    $role = strtolower($_SESSION['user_role']);
}

// Eğer şu an admin klasöründeysek path farkı ayarla
$prefix = (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../' : '';

// Sepet sayısını hesapla (adet toplamı)
$cartCount = 0;
if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    $cartCount = array_sum($_SESSION['cart']);
}
?>
<header class="header">
    <div class="container">
        <div class="header-content">
            <!-- Logo -->
            <div class="logo">
                <a href="<?php echo $prefix; ?>index.php">
                    <h1><i class="fas fa-book"></i> BOSS</h1>
                    <span>Book Ordering System</span>
                </a>
            </div>

            <!-- Navigasyon -->
            <nav class="nav">
                <a href="<?php echo $prefix; ?>index.php" class="nav-link">Home</a>
                <a href="<?php echo $prefix; ?>books.php" class="nav-link">Books</a>
                <a href="<?php echo $prefix; ?>categories.php" class="nav-link">Categories</a>
                <a href="<?php echo $prefix; ?>authors.php" class="nav-link">Authors</a>

                <?php if (isLoggedIn()): ?>
                    <a href="<?php echo $prefix; ?>orders.php" class="nav-link">My Orders</a>
                    <a href="<?php echo $prefix; ?>profile.php" class="nav-link">Profile</a>

                    <?php if ($role === 'employee' || $role === 'admin'): ?>
                        <a href="<?php echo $prefix; ?>admin/employee_dashboard.php" class="nav-link">Employee</a>
                    <?php endif; ?>

                    <?php if ($role === 'admin'): ?>
                        <a href="<?php echo $prefix; ?>admin/admin_dashboard.php" class="nav-link">Admin</a>
                    <?php endif; ?>

                    <!-- Logout -->
                    <a href="<?php echo ($role === 'admin') ? $prefix . 'admin/logout.php' : $prefix . 'logout_rbac.php'; ?>" class="nav-link">
                        Logout
                    </a>

                <?php else: ?>
                    <a href="<?php echo $prefix; ?>login.php" class="nav-link">Login</a>
                    <a href="<?php echo $prefix; ?>register.php" class="nav-link">Register</a>
                <?php endif; ?>
            </nav>

            <!-- Arama ve Sepet -->
            <div class="header-actions">
                <div class="search-box">
                    <form method="get" action="<?php echo $prefix; ?>books.php" style="display:flex;gap:5px;">
                        <input type="text" name="search" placeholder="Search books..."
                               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit"><i class="fas fa-search"></i></button>
                    </form>
                </div>
                <a href="<?php echo $prefix; ?>cart.php" class="cart-btn">
                    <i class="fas fa-shopping-cart"></i>
                    <span class="cart-count"><?php echo $cartCount; ?></span>
                </a>
            </div>
        </div>
    </div>
</header>