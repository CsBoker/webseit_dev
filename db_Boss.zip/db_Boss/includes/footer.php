<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h4>BOSS</h4>
                <p>Your trusted book ordering system for all your reading needs.</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <a href="books.php">All Books</a>
                <a href="authors.php">Authors</a>
                <a href="categories.php">Categories</a>
                <a href="about.php">About Us</a>
            </div>
            <div class="footer-section">
                <h4>Account</h4>
                <?php if (isLoggedIn()): ?>
                    <a href="profile.php">My Profile</a>
                    <a href="orders.php">My Orders</a>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php">Register</a>
                <?php endif; ?>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p><i class="fas fa-envelope"></i> info@boss-books.com</p>
                <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                <p><i class="fas fa-map-marker-alt"></i> 123 Book Street, Reading City</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 BOSS - Book Ordering System. All rights reserved.</p>
        </div>
    </div>
</footer>
