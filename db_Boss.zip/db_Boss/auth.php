<?php
// auth.php — session helpers and role-based guards for BOSS
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}

function current_role(): string {
    /*
     * Normalized role string (lowercase).
     *
     * Historically the application has used two different session keys
     * to store the logged in user's role:
     *   - `$_SESSION['role']` is used by the RBAC login flow (login_process.php).
     *   - `$_SESSION['user_role']` is used by the OO User::login() method.
     *
     * When one of these values is not set the other should be used as a
     * fallback.  If neither is present we default to the customer role.
     * Additionally we allow falling back to the account type (`user_type`)
     * as a last resort, so that an employee account with no explicit role
     * still receives elevated permissions.
     */
    // Prefer the explicit RBAC role
    if (isset($_SESSION['role']) && $_SESSION['role'] !== '') {
        return strtolower((string)$_SESSION['role']);
    }
    // Fall back to the OO style role
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] !== '') {
        return strtolower((string)$_SESSION['user_role']);
    }
    // As a last resort look at the account type
    if (isset($_SESSION['user_type']) && $_SESSION['user_type'] !== '') {
        $type = strtolower((string)$_SESSION['user_type']);
        if (in_array($type, ['admin','employee','customer'], true)) {
            return $type;
        }
    }
    return 'customer';
}

function require_login(): void {
    if (!is_logged_in()) {
        header("Location: /login.php?e=not_logged_in");
        exit();
    }
}

function require_role($allowed): void {
    // $allowed can be a string or array of strings
    $role = current_role();
    $allowed_list = is_array($allowed) ? array_map('strtolower', $allowed) : [strtolower($allowed)];
    if (!in_array($role, $allowed_list, true)) {
        http_response_code(403);
        echo "<h1>Access denied</h1><p>Your role (<code>" . htmlspecialchars($role) . "</code>) is not permitted here.</p>";
        echo '<p><a href="/customer_dashboard.php">Go back</a></p>';
        exit();
    }
}
?>
