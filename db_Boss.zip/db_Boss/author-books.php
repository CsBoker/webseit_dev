<?php
/**
 * Display all books written by a specific author.
 *
 * This page is linked from the Authors listing.  It expects an
 * `id` query parameter corresponding to the author identifier.  If
 * no valid ID is supplied or the author cannot be found the user is
 * redirected back to the authors page.  Book information is
 * retrieved via the `Author` model which internally joins against
 * the Book table.  Results are rendered in a grid similar to the
 * standard books listing.
 */

require_once 'config/config.php';

$authorModel = new Author();

// Parse and validate author id from the query string
$authorId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($authorId <= 0) {
    header('Location: authors.php');
    exit();
}

// Fetch author details and their books
$author = $authorModel->getAuthorById($authorId);
if (!$author) {
    header('Location: authors.php');
    exit();
}
$books = $authorModel->getAuthorBooks($authorId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($author['first_name'] . ' ' . $author['last_name']); ?> - Books | <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1>Books by <?php echo htmlspecialchars($author['first_name'] . ' ' . $author['last_name']); ?></h1>
                <?php if ($author['date_birth'] || $author['date_death']): ?>
                    <p>
                        <?php
                        if ($author['date_birth']) {
                            echo date('Y', strtotime($author['date_birth']));
                        }
                        if ($author['date_death']) {
                            echo ' – ' . date('Y', strtotime($author['date_death']));
                        } elseif ($author['date_birth']) {
                            echo ' – Present';
                        }
                        ?>
                    </p>
                <?php endif; ?>
                <?php if ($author['remark']): ?>
                    <p><?php echo htmlspecialchars($author['remark']); ?></p>
                <?php endif; ?>
            </div>

            <?php if (empty($books)): ?>
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>No books found for this author</h3>
                    <p>Return to the <a href="authors.php">authors page</a> or browse all <a href="books.php">books</a>.</p>
                </div>
            <?php else: ?>
                <div class="books-grid">
                    <?php foreach ($books as $book): ?>
                        <div class="book-card">
                            <div class="book-image">
                                <?php
                                $imagePath = 'images/books/' . $book['image'];
                                $fullPath = __DIR__ . '/' . $imagePath;
                                if (!empty($book['image']) && file_exists($fullPath)):
                                ?>
                                    <img src="<?php echo $imagePath; ?>" alt="<?php echo htmlspecialchars($book['title']); ?>" class="book-cover">
                                <?php else: ?>
                                    <img src="images/books/default.jpg" alt="No cover available" class="book-cover">
                                <?php endif; ?>
                            </div>
                            <div class="book-info">
                                <h4 class="book-title">
                                    <a href="book-details.php?id=<?php echo $book['id_book']; ?>">
                                        <?php echo htmlspecialchars($book['title']); ?>
                                    </a>
                                </h4>
                                <p class="book-category">
                                    <?php echo htmlspecialchars($book['category_name'] ?? ''); ?>
                                </p>
                                <p class="book-price">$<?php echo number_format($book['price'], 2); ?></p>
                                <div class="book-actions">
                                    <button class="btn btn-primary" onclick="addToCart(<?php echo $book['id_book']; ?>)">
                                        <i class="fas fa-cart-plus"></i> Add to Cart
                                    </button>
                                    <a href="book-details.php?id=<?php echo $book['id_book']; ?>" class="btn">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>