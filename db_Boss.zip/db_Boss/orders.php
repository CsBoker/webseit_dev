<?php 
require_once 'config/config.php';

if (!isLoggedIn()) {
    $redirectUrl = urlencode('orders.php');
    header("Location: login.php?redirect={$redirectUrl}");
    exit;
}

$orderModel = new Order();
$userId = $_SESSION['user_id'];
$orders = $orderModel->getUserOrders($userId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .orders-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .orders-table th, .orders-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }
        .orders-table th {
            background: #f8f9fa;
            font-weight: bold;
        }
        .orders-table tr:nth-child(even) {
            background: #fdfdfd;
        }
        .status {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.9em;
            font-weight: bold;
        }
        .status.paid { background: #d1fae5; color: #065f46; }
        .status.processing { background: #dbeafe; color: #1e40af; }
        .status.cancelled { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1><i class="fas fa-box"></i> My Orders</h1>
                <p>Review your recent purchases and order details</p>
            </div>

            <?php if (empty($orders)): ?>
                <div class="no-results">
                    <i class="fas fa-box-open"></i>
                    <h3>No orders found</h3>
                    <p>Looks like you haven't placed any orders yet.</p>
                    <a href="books.php" class="btn btn-primary">Browse Books</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="orders-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Items</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): 
                                $status = strtolower($order['status_description']);
                                $statusClass = 'processing';
                                if (strpos($status, 'paid') !== false) $statusClass = 'paid';
                                elseif (strpos($status, 'cancelled') !== false) $statusClass = 'cancelled';
                            ?>
                                <tr>
                                    <td>#<?php echo (int)$order['id_order']; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($order['date_order'])); ?></td>
                                    <td><span class="status <?php echo $statusClass; ?>">
                                        <?php echo htmlspecialchars($order['status_description']); ?>
                                    </span></td>
                                    <td><?php echo (int)$order['item_count']; ?></td>
                                    <td><?php echo number_format((float)($order['total_amount'] ?? 0), 2); ?> €</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>