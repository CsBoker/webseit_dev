-- --------------------------------------------------------------------
-- 1. Database creation and table definitions
-- --------------------------------------------------------------------
DROP DATABASE IF EXISTS db_boss;
CREATE DATABASE db_boss;
USE db_boss;

-- Disable foreign key checks during schema creation and data load.
SET FOREIGN_KEY_CHECKS = 0;

-- Create tables as defined in the Abfrage file, with modifications.

CREATE TABLE AccountType (
    id_type INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(45) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE AccountRole (
    id_role INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(45) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE Account (
    id_account INT AUTO_INCREMENT PRIMARY KEY,
    account_name VARCHAR(45),
    date_created DATE,
    first_name VARCHAR(45),
    last_name VARCHAR(45),
    date_birth DATE,
    email VARCHAR(255) UNIQUE,
    password_hash VARCHAR(255),
    phone VARCHAR(20),
    remark TEXT,
    id_type INT,
    id_role INT,
    FOREIGN KEY (id_type) REFERENCES AccountType(id_type)
        ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_role) REFERENCES AccountRole(id_role)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE Country (
    id_country INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code CHAR(2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE Address (
    id_address INT AUTO_INCREMENT PRIMARY KEY,
    address1 VARCHAR(100),
    address2 VARCHAR(100),
    city VARCHAR(45),
    zip VARCHAR(10),
    id_country INT,
    FOREIGN KEY (id_country) REFERENCES Country(id_country)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE Language (
    id_language INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code CHAR(2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE Category (
    id_category INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT
) ENGINE=InnoDB;

CREATE TABLE Author (
    id_author INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(45),
    last_name VARCHAR(45),
    date_birth DATE,
    date_death DATE,
    remark TEXT
) ENGINE=InnoDB;

CREATE TABLE Publisher (
    id_publisher INT AUTO_INCREMENT PRIMARY KEY,
    publisher_name VARCHAR(100),
    founded DATE,
    website VARCHAR(100),
    remark TEXT
) ENGINE=InnoDB;

CREATE TABLE Book (
    id_book INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    isbn VARCHAR(14),
    edition INT,
    published DATE,
    info TEXT,
    image LONGBLOB,
    is_in_stock BOOLEAN,
    price DECIMAL(5,2),
    amount INT,
    last_changed DATETIME,
    id_publisher INT,
    id_category INT,
    id_language INT,
    FOREIGN KEY (id_publisher) REFERENCES Publisher(id_publisher)
        ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_category) REFERENCES Category(id_category)
        ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_language) REFERENCES Language(id_language)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE Author_has_Book (
    id_author INT,
    id_book INT,
    PRIMARY KEY (id_author, id_book),
    FOREIGN KEY (id_author) REFERENCES Author(id_author)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_book) REFERENCES Book(id_book)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE OrderStatus (
    id_order_status INT AUTO_INCREMENT PRIMARY KEY,
    status_code VARCHAR(10),
    description VARCHAR(100)
) ENGINE=InnoDB;

CREATE TABLE Orders (
    id_order INT AUTO_INCREMENT PRIMARY KEY,
    date_order DATE,
    shipping_address TEXT,
    last_changed DATETIME,
    id_account INT,
    id_order_status INT,
    FOREIGN KEY (id_account) REFERENCES Account(id_account)
        ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_order_status) REFERENCES OrderStatus(id_order_status)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE OrderDetails (
    id_order_details INT AUTO_INCREMENT PRIMARY KEY,
    item_count INT,
    id_order INT,
    id_book INT,
    FOREIGN KEY (id_order) REFERENCES Orders(id_order)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_book) REFERENCES Book(id_book)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE OrderHistory (
    id_order_history INT AUTO_INCREMENT PRIMARY KEY,
    date_order DATE,
    shipping_address TEXT,
    last_changed DATETIME,
    id_order INT,
    FOREIGN KEY (id_order) REFERENCES Orders(id_order)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE Stock (
    id_stock INT AUTO_INCREMENT PRIMARY KEY,
    amount INT,
    price DECIMAL(5,2),
    date_price DATE,
    last_changed DATETIME,
    id_book INT,
    FOREIGN KEY (id_book) REFERENCES Book(id_book)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE StockHistory (
    id_stock_history INT AUTO_INCREMENT PRIMARY KEY,
    amount INT,
    price DECIMAL(5,2),
    date_price DATE,
    last_changed DATETIME,
    id_stock INT,
    FOREIGN KEY (id_stock) REFERENCES Stock(id_stock)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE Message (
    id_message INT AUTO_INCREMENT PRIMARY KEY,
    timestamp_message DATETIME,
    message_content TEXT,
    id_account INT,
    FOREIGN KEY (id_account) REFERENCES Account(id_account)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE MessageClosure (
    ancestor INT,
    descendant INT,
    PRIMARY KEY (ancestor, descendant),
    FOREIGN KEY (ancestor) REFERENCES Message(id_message)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (descendant) REFERENCES Message(id_message)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 2. Load static lookup data (account types, roles, languages, countries,
--    categories, authors, publishers)
-- --------------------------------------------------------------------

-- Account types and roles
INSERT INTO AccountType (type_name) VALUES
('Customer'),
('Employee'),
('Admin');

INSERT INTO AccountRole (role_name) VALUES
('Reader'),
('Buyer'),
('Manager'),
('Admin');

-- Languages (ISO 639‑1).  This list is copied verbatim from the
-- language #3.sql file and preserves insertion order.
INSERT INTO Language (name, code) VALUES
('Abkhazian', 'ab'),
('Afar', 'aa'),
('Afrikaans', 'af'),
('Akan', 'ak'),
('Albanian', 'sq'),
('Amharic', 'am'),
('Arabic', 'ar'),
('Aragonese', 'an'),
('Armenian', 'hy'),
('Assamese', 'as'),
('Avaric', 'av'),
('Avestan', 'ae'),
('Aymara', 'ay'),
('Azerbaijani', 'az'),
('Bambara', 'bm'),
('Bashkir', 'ba'),
('Basque', 'eu'),
('Belarusian', 'be'),
('Bengali', 'bn'),
('Bislama', 'bi'),
('Bokmål, Norwegian', 'nb'),
('Bosnian', 'bs'),
('Breton', 'br'),
('Bulgarian', 'bg'),
('Burmese', 'my'),
('Catalan', 'ca'),
('Central Khmer', 'km'),
('Chamorro', 'ch'),
('Chechen', 'ce'),
('Chewa', 'ny'),
('Chinese', 'zh'),
('Chuang', 'za'),
('Church Slavic', 'cu'),
('Chuvash', 'cv'),
('Cornish', 'kw'),
('Corsican', 'co'),
('Cree', 'cr'),
('Croatian', 'hr'),
('Czech', 'cs'),
('Danish', 'da'),
('Dhivehi', 'dv'),
('Dutch', 'nl'),
('Dzongkha', 'dz'),
('English', 'en'),
('Esperanto', 'eo'),
('Estonian', 'et'),
('Ewe', 'ee'),
('Faroese', 'fo'),
('Fijian', 'fj'),
('Finnish', 'fi'),
('French', 'fr'),
('Fulah', 'ff'),
('Gaelic', 'gd'),
('Galician', 'gl'),
('Ganda', 'lg'),
('Georgian', 'ka'),
('German', 'de'),
('Gikuyu', 'ki'),
('Greek, Modern (1453-)', 'el'),
('Greenlandic', 'kl'),
('Guarani', 'gn'),
('Gujarati', 'gu'),
('Haitian', 'ht'),
('Hausa', 'ha'),
('Hebrew', 'he'),
('Herero', 'hz'),
('Hindi', 'hi'),
('Hiri Motu', 'ho'),
('Hungarian', 'hu'),
('Icelandic', 'is'),
('Ido', 'io'),
('Igbo', 'ig'),
('Indonesian', 'id'),
('Interlingue', 'ie'),
('Inuktitut', 'iu'),
('Inupiaq', 'ik'),
('Irish', 'ga'),
('Italian', 'it'),
('Japanese', 'ja'),
('Javanese', 'jv'),
('Kannada', 'kn'),
('Kanuri', 'kr'),
('Kashmiri', 'ks'),
('Kazakh', 'kk'),
('Kinyarwanda', 'rw'),
('Kirghiz', 'ky'),
('Komi', 'kv'),
('Kongo', 'kg'),
('Korean', 'ko'),
('Kuanyama', 'kj'),
('Kurdish', 'ku'),
('Lao', 'lo'),
('Latin', 'la'),
('Latvian', 'lv'),
('Letzeburgesch', 'lb'),
('Limburgan', 'li'),
('Lingala', 'ln'),
('Lithuanian', 'lt'),
('Luba-Katanga', 'lu'),
('Macedonian', 'mk'),
('Malagasy', 'mg'),
('Malay', 'ms'),
('Malayalam', 'ml'),
('Maltese', 'mt'),
('Manx', 'gv'),
('Maori', 'mi'),
('Marathi', 'mr'),
('Marshallese', 'mh'),
('Moldavian', 'ro'),
('Mongolian', 'mn'),
('Nauru', 'na'),
('Navaho', 'nv'),
('Ndebele, North', 'nd'),
('Ndebele, South', 'nr'),
('Ndonga', 'ng'),
('Nepali', 'ne'),
('Northern Sami', 'se'),
('Norwegian', 'no'),
('Norwegian Nynorsk', 'nn'),
('Nuosu', 'ii'),
('Occitan (post 1500)', 'oc'),
('Ojibwa', 'oj'),
('Oriya', 'or'),
('Oromo', 'om'),
('Ossetian', 'os'),
('Pali', 'pi'),
('Panjabi', 'pa'),
('Pashto', 'ps'),
('Persian', 'fa'),
('Polish', 'pl'),
('Portuguese', 'pt'),
('Quechua', 'qu'),
('Romansh', 'rm'),
('Rundi', 'rn'),
('Russian', 'ru'),
('Samoan', 'sm'),
('Sango', 'sg'),
('Sanskrit', 'sa'),
('Sardinian', 'sc'),
('Serbian', 'sr'),
('Shona', 'sn'),
('Sindhi', 'sd'),
('Sinhala', 'si'),
('Slovak', 'sk'),
('Slovenian', 'sl'),
('Somali', 'so'),
('Sotho, Southern', 'st'),
('Spanish', 'es'),
('Sundanese', 'su'),
('Swahili', 'sw'),
('Swati', 'ss'),
('Swedish', 'sv'),
('Tagalog', 'tl'),
('Tahitian', 'ty'),
('Tajik', 'tg'),
('Tamil', 'ta'),
('Tatar', 'tt'),
('Telugu', 'te'),
('Thai', 'th'),
('Tibetan', 'bo'),
('Tigrinya', 'ti'),
('Tonga (Tonga Islands)', 'to'),
('Tsonga', 'ts'),
('Tswana', 'tn'),
('Turkish', 'tr'),
('Turkmen', 'tk'),
('Twi', 'tw'),
('Uighur', 'ug'),
('Ukrainian', 'uk'),
('Urdu', 'ur'),
('Uzbek', 'uz'),
('Venda', 've'),
('Vietnamese', 'vi'),
('Volapük', 'vo'),
('Walloon', 'wa'),
('Welsh', 'cy'),
('Western Frisian', 'fy'),
('Wolof', 'wo'),
('Xhosa', 'xh'),
('Yiddish', 'yi'),
('Yoruba', 'yo'),
('Zulu', 'zu');

-- Countries (ISO 3166).  The list below mirrors the data provided in
-- country.sql.  It is long, but including it verbatim ensures all
-- referenced country IDs exist when addresses are inserted.  The
-- order is preserved so the id_country values match the ones used in
-- the original sample addresses.  Each line inserts a (name, code)
-- pair.
INSERT INTO Country (name, code) VALUES
('Aruba', 'AW'),
('Afghanistan', 'AF'),
('Angola', 'AO'),
('Anguilla', 'AI'),
('Åland Islands', 'AX'),
('Albania', 'AL'),
('Andorra', 'AD'),
('United Arab Emirates', 'AE'),
('Argentina', 'AR'),
('Armenia', 'AM'),
('American Samoa', 'AS'),
('Antarctica', 'AQ'),
('French Southern Territories', 'TF'),
('Antigua and Barbuda', 'AG'),
('Australia', 'AU'),
('Austria', 'AT'),
('Azerbaijan', 'AZ'),
('Burundi', 'BI'),
('Belgium', 'BE'),
('Benin', 'BJ'),
('Bonaire, Sint Eustatius and Saba', 'BQ'),
('Burkina Faso', 'BF'),
('Bangladesh', 'BD'),
('Bulgaria', 'BG'),
('Bahrain', 'BH'),
('Bahamas', 'BS'),
('Bosnia and Herzegovina', 'BA'),
('Saint Barthélemy', 'BL'),
('Belarus', 'BY'),
('Belize', 'BZ'),
('Bermuda', 'BM'),
('Bolivia, Plurinational State of', 'BO'),
('Brazil', 'BR'),
('Barbados', 'BB'),
('Brunei Darussalam', 'BN'),
('Bhutan', 'BT'),
('Bouvet Island', 'BV'),
('Botswana', 'BW'),
('Central African Republic', 'CF'),
('Canada', 'CA'),
('Cocos (Keeling) Islands', 'CC'),
('Switzerland', 'CH'),
('Chile', 'CL'),
('China', 'CN'),
('Côte d''Ivoire', 'CI'),
('Cameroon', 'CM'),
('Congo, The Democratic Republic of the', 'CD'),
('Congo', 'CG'),
('Cook Islands', 'CK'),
('Colombia', 'CO'),
('Comoros', 'KM'),
('Cabo Verde', 'CV'),
('Costa Rica', 'CR'),
('Cuba', 'CU'),
('Curaçao', 'CW'),
('Christmas Island', 'CX'),
('Cayman Islands', 'KY'),
('Cyprus', 'CY'),
('Czechia', 'CZ'),
('Germany', 'DE'),
('Djibouti', 'DJ'),
('Dominica', 'DM'),
('Denmark', 'DK'),
('Dominican Republic', 'DO'),
('Algeria', 'DZ'),
('Ecuador', 'EC'),
('Egypt', 'EG'),
('Eritrea', 'ER'),
('Western Sahara', 'EH'),
('Spain', 'ES'),
('Estonia', 'EE'),
('Ethiopia', 'ET'),
('Finland', 'FI'),
('Fiji', 'FJ'),
('Falkland Islands (Malvinas)', 'FK'),
('France', 'FR'),
('Faroe Islands', 'FO'),
('Micronesia, Federated States of', 'FM'),
('Gabon', 'GA'),
('United Kingdom', 'GB'),
('Georgia', 'GE'),
('Guernsey', 'GG'),
('Ghana', 'GH'),
('Gibraltar', 'GI'),
('Guinea', 'GN'),
('Guadeloupe', 'GP'),
('Gambia', 'GM'),
('Guinea-Bissau', 'GW'),
('Equatorial Guinea', 'GQ'),
('Greece', 'GR'),
('Grenada', 'GD'),
('Greenland', 'GL'),
('Guatemala', 'GT'),
('French Guiana', 'GF'),
('Guam', 'GU'),
('Guyana', 'GY'),
('Hong Kong', 'HK'),
('Heard Island and McDonald Islands', 'HM'),
('Honduras', 'HN'),
('Croatia', 'HR'),
('Haiti', 'HT'),
('Hungary', 'HU'),
('Indonesia', 'ID'),
('Isle of Man', 'IM'),
('India', 'IN'),
('British Indian Ocean Territory', 'IO'),
('Ireland', 'IE'),
('Iran, Islamic Republic of', 'IR'),
('Iraq', 'IQ'),
('Iceland', 'IS'),
('Israel', 'IL'),
('Italy', 'IT'),
('Jamaica', 'JM'),
('Jersey', 'JE'),
('Jordan', 'JO'),
('Japan', 'JP'),
('Kazakhstan', 'KZ'),
('Kenya', 'KE'),
('Kyrgyzstan', 'KG'),
('Cambodia', 'KH'),
('Kiribati', 'KI'),
('Saint Kitts and Nevis', 'KN'),
('Korea, Republic of', 'KR'),
('Kuwait', 'KW'),
('Lao People''s Democratic Republic', 'LA'),
('Lebanon', 'LB'),
('Liberia', 'LR'),
('Libya', 'LY'),
('Saint Lucia', 'LC'),
('Liechtenstein', 'LI'),
('Sri Lanka', 'LK'),
('Lesotho', 'LS'),
('Lithuania', 'LT'),
('Luxembourg', 'LU'),
('Latvia', 'LV'),
('Macao', 'MO'),
('Saint Martin (French part)', 'MF'),
('Morocco', 'MA'),
('Monaco', 'MC'),
('Moldova, Republic of', 'MD'),
('Madagascar', 'MG'),
('Maldives', 'MV'),
('Mexico', 'MX'),
('Marshall Islands', 'MH'),
('North Macedonia', 'MK'),
('Mali', 'ML'),
('Malta', 'MT'),
('Myanmar', 'MM'),
('Montenegro', 'ME'),
('Mongolia', 'MN'),
('Northern Mariana Islands', 'MP'),
('Mozambique', 'MZ'),
('Mauritania', 'MR'),
('Montserrat', 'MS'),
('Martinique', 'MQ'),
('Mauritius', 'MU'),
('Malawi', 'MW'),
('Malaysia', 'MY'),
('Mayotte', 'YT'),
('Namibia', 'NA'),
('New Caledonia', 'NC'),
('Niger', 'NE'),
('Norfolk Island', 'NF'),
('Nigeria', 'NG'),
('Nicaragua', 'NI'),
('Niue', 'NU'),
('Netherlands', 'NL'),
('Norway', 'NO'),
('Nepal', 'NP'),
('Nauru', 'NR'),
('New Zealand', 'NZ'),
('Oman', 'OM'),
('Pakistan', 'PK'),
('Panama', 'PA'),
('Pitcairn', 'PN'),
('Peru', 'PE'),
('Philippines', 'PH'),
('Palau', 'PW'),
('Papua New Guinea', 'PG'),
('Poland', 'PL'),
('Puerto Rico', 'PR'),
('Korea, Democratic People''s Republic of', 'KP'),
('Portugal', 'PT'),
('Paraguay', 'PY'),
('Palestine, State of', 'PS'),
('French Polynesia', 'PF'),
('Qatar', 'QA'),
('Réunion', 'RE'),
('Romania', 'RO'),
('Russian Federation', 'RU'),
('Rwanda', 'RW'),
('Saudi Arabia', 'SA'),
('Sudan', 'SD'),
('Senegal', 'SN'),
('Singapore', 'SG'),
('South Georgia and the South Sandwich Islands', 'GS'),
('Saint Helena, Ascension and Tristan da Cunha', 'SH'),
('Svalbard and Jan Mayen', 'SJ'),
('Solomon Islands', 'SB'),
('Sierra Leone', 'SL'),
('El Salvador', 'SV'),
('San Marino', 'SM'),
('Somalia', 'SO'),
('Saint Pierre and Miquelon', 'PM'),
('Serbia', 'RS'),
('South Sudan', 'SS'),
('Sao Tome and Principe', 'ST'),
('Suriname', 'SR'),
('Slovakia', 'SK'),
('Slovenia', 'SI'),
('Sweden', 'SE'),
('Swaziland', 'SZ'),
('Sint Maarten (Dutch part)', 'SX'),
('Seychelles', 'SC'),
('Syrian Arab Republic', 'SY'),
('Turks and Caicos Islands', 'TC'),
('Chad', 'TD'),
('Togo', 'TG'),
('Thailand', 'TH'),
('Tajikistan', 'TJ'),
('Tokelau', 'TK'),
('Timor-Leste', 'TL'),
('Turkmenistan', 'TM'),
('Tunisia', 'TN'),
('Tonga', 'TO'),
('Turkey', 'TR'),
('Trinidad and Tobago', 'TT'),
('Tuvalu', 'TV'),
('Taiwan, Province of China', 'TW'),
('Tanzania, United Republic of', 'TZ'),
('Uganda', 'UG'),
('Ukraine', 'UA'),
('Uruguay', 'UY'),
('United States Minor Outlying Islands', 'UM'),
('United States', 'US'),
('Uzbekistan', 'UZ'),
('Holy See (Vatican City State)', 'VA'),
('Saint Vincent and the Grenadines', 'VC'),
('Venezuela, Bolivarian Republic of', 'VE'),
('Virgin Islands, British', 'VG'),
('Virgin Islands, U.S.', 'VI'),
('Viet Nam', 'VN'),
('Vanuatu', 'VU'),
('Wallis and Futuna', 'WF'),
('Samoa', 'WS'),
('Yemen', 'YE'),
('South Africa', 'ZA'),
('Zambia', 'ZM'),
('Zimbabwe', 'ZW');

-- Categories.  The leading stray token `category` and trailing SELECT
-- from the source file have been removed.  Each category includes a
-- name and a description.
INSERT INTO Category (category_name, description) VALUES
('Fiction', 'Imaginative or invented stories'),
('Non-fiction', 'Based on real events and facts'),
('Science', 'Books about scientific topics and discoveries'),
('Fantasy', 'Stories with magical or supernatural elements'),
('History', 'Books about historical events and figures'),
('Biography', 'Life stories of real people'),
('Children', 'Books written for children'),
('Mystery', 'Suspenseful stories with secrets or crimes'),
('Romance', 'Love and romantic relationships'),
('Horror', 'Books meant to scare or shock'),
('Self-help', 'Guides for personal development'),
('Philosophy', 'Books exploring fundamental questions of existence'),
('Psychology', 'Books on human mind and behavior'),
('Religion', 'Books about belief systems and spirituality'),
('Education', 'Textbooks and learning materials'),
('Health', 'Books about physical or mental health'),
('Politics', 'Books about governments and public affairs'),
('Art', 'Books on visual or performing arts'),
('Travel', 'Travel guides and journey accounts'),
('Comics', 'Graphic novels and comic strips'),
('Poetry', 'Collections of poems and verse'),
('Drama', 'Plays and theatrical literature'),
('Economics', 'Books on finance, trade, and markets'),
('Law', 'Books about legal systems and practices'),
('Technology', 'Books about modern innovations and tools');

-- Authors.  IDs are supplied explicitly to preserve the original
-- numbering.  This list consolidates the four INSERT statements in
-- author #4.sql into one continuous insert.
INSERT INTO Author (id_author, first_name, last_name, date_birth, date_death, remark) VALUES
 (1, 'Harper', 'Lee', '1926-04-28', '2016-02-19', NULL),
 (2, 'Toni', 'Morrison', '1931-02-18', '2019-08-05', NULL),
 (3, 'F. Scott', 'Fitzgerald', '1896-09-24', '1940-12-21', NULL),
 (4, 'Chinua', 'Achebe', '1930-11-16', '2013-03-21', NULL),
 (5, 'Khaled', 'Hosseini', '1965-03-04', NULL, NULL),
 (6, 'J.K.', 'Rowling', '1965-07-31', NULL, NULL),
 (7, 'J.R.R.', 'Tolkien', '1892-01-03', '1973-09-02', NULL),
 (8, 'George R.R.', 'Martin', '1948-09-20', NULL, NULL),
 (9, 'Patrick', 'Rothfuss', '1973-06-06', NULL, NULL),
 (10, 'Brandon', 'Sanderson', '1975-12-19', NULL, NULL),
 (11, 'Jared', 'Diamond', '1937-09-10', NULL, NULL),
 (12, 'Susan Wise', 'Bauer', '1968-07-08', NULL, NULL),
 (13, 'Mary', 'Beard', '1955-01-01', NULL, NULL),
 (14, 'Howard', 'Zinn', '1922-08-24', '2010-01-27', NULL),
 (15, 'Peter', 'Frankopan', '1971-01-01', NULL, NULL),
 (16, 'Nelson', 'Mandela', '1918-07-18', '2013-12-05', NULL),
 (17, 'Anne', 'Frank', '1929-06-12', '1945-02-01', NULL),
 (18, 'Walter', 'Isaacson', '1952-05-20', NULL, NULL),
 (19, 'Malala', 'Yousafzai', '1997-07-12', NULL, NULL),
 (20, 'Michelle', 'Obama', '1964-01-17', NULL, NULL),
 (21, 'Tara', 'Westover', '1986-09-27', NULL, NULL),
 (22, 'Malcolm', 'Gladwell', '1963-09-03', NULL, NULL),
 (23, 'Daniel', 'Kahneman', '1934-03-05', NULL, 'Nobel laureate in Economics'),
 (24, 'Rebecca', 'Skloot', '1972-08-19', NULL, NULL),
 (25, 'Susan', 'Cain', '1968-12-24', NULL, NULL),
 (26, 'Stephen', 'Hawking', '1942-01-08', '2018-03-14', NULL),
 (27, 'Richard', 'Dawkins', '1941-03-26', NULL, NULL),
 (28, 'Carl', 'Sagan', '1934-11-09', '1996-12-20', NULL),
 (29, 'Brian', 'Greene', '1963-02-09', NULL, NULL),
 (30, 'Siddhartha', 'Mukherjee', '1970-07-21', NULL, NULL),
 (31, 'E. B.', 'White', '1899-07-11', '1985-10-01', NULL),
 (32, 'Julia', 'Donaldson', '1948-09-16', NULL, NULL),
 (33, 'Maurice', 'Sendak', '1928-06-10', '2012-05-08', NULL),
 (34, 'Roald', 'Dahl', '1916-09-13', '1990-11-23', NULL),
 (35, 'Margaret Wise', 'Brown', '1910-05-23', '1952-11-13', NULL),
 (36, 'Stieg', 'Larsson', '1954-08-15', '2004-11-09', NULL),
 (37, 'Gillian', 'Flynn', '1971-02-24', NULL, NULL),
 (38, 'Dan', 'Brown', '1964-06-22', NULL, NULL),
 (39, 'Agatha', 'Christie', '1890-09-15', '1976-01-12', NULL),
 (40, 'Jane', 'Austen', '1775-12-16', '1817-07-18', NULL),
 (41, 'Jojo', 'Moyes', '1969-08-04', NULL, NULL),
 (42, 'Nicholas', 'Sparks', '1965-12-31', NULL, NULL),
 (43, 'Stephenie', 'Meyer', '1973-12-24', NULL, NULL),
 (44, 'Diana', 'Gabaldon', '1952-01-11', NULL, NULL),
 (45, 'Stephen', 'King', '1947-09-21', NULL, NULL),
 (46, 'Bram', 'Stoker', '1847-11-08', '1912-04-20', NULL),
 (47, 'Mary', 'Shelley', '1797-08-30', '1851-02-01', NULL),
 (48, 'Shirley', 'Jackson', '1916-12-14', '1965-08-08', NULL),
 (49, 'Josh', 'Malerman', '1975-07-24', NULL, NULL),
 (50, 'Stephen', 'Covey', '1932-10-24', '2012-07-16', NULL),
 (51, 'James', 'Clear', '1986-01-22', NULL, NULL),
 (52, 'Dale', 'Carnegie', '1888-11-24', '1955-11-01', NULL),
 (53, 'Plato', '', '0427-01-01', '0347-01-01', 'Greek philosopher'),
 (54, 'Marcus', 'Aurelius', '0121-04-26', '0180-03-17', 'Roman emperor'),
 (55, 'Friedrich', 'Nietzsche', '1844-10-15', '1900-08-25', NULL),
 (56, 'Viktor', 'Frankl', '1905-03-26', '1997-09-02', NULL),
 (57, 'Sigmund', 'Freud', '1856-05-06', '1939-09-23', NULL),
 (58, 'Mihaly', 'Csikszentmihalyi', '1934-09-29', '2021-10-20', NULL),
 (59, 'Various', 'Authors', NULL, NULL, 'Religious text'),
 (60, 'Paulo', 'Coelho', '1947-08-24', NULL, NULL),
 (61, 'Ken', 'Robinson', '1950-03-04', '2020-08-21', NULL),
 (62, 'bell', 'hooks', '1952-09-25', '2021-12-15', NULL),
 (63, 'Bessel', 'van der Kolk', '1943-05-01', NULL, NULL),
 (64, 'Matthew', 'Walker', '1973-06-19', NULL, NULL),
 (65, 'Michael', 'Greger', '1972-10-25', NULL, NULL),
 (66, 'Niccolò', 'Machiavelli', '1469-05-03', '1527-06-21', NULL),
 (67, 'Karl', 'Marx', '1818-05-05', '1883-03-14', NULL),
 (68, 'Friedrich', 'Hayek', '1899-05-08', '1992-03-23', NULL),
 (69, 'John', 'Berger', '1926-11-05', '2017-01-02', NULL),
 (70, 'E.H.', 'Gombrich', '1909-03-30', '2001-11-03', NULL),
 (71, 'Josef', 'Albers', '1888-03-19', '1976-03-25', NULL),
 (72, 'Jon', 'Krakauer', '1954-04-12', NULL, NULL),
 (73, 'Bruce', 'Chatwin', '1940-05-13', '1989-01-18', NULL),
 (74, 'Elizabeth', 'Gilbert', '1969-07-18', NULL, NULL),
 (75, 'Alan', 'Moore', '1953-11-18', NULL, NULL),
 (76, 'Art', 'Spiegelman', '1948-02-15', NULL, NULL),
 (77, 'Marjane', 'Satrapi', '1969-11-22', NULL, NULL),
 (78, 'T.S.', 'Eliot', '1888-09-26', '1965-01-04', NULL),
 (79, 'Rupi', 'Kaur', '1992-10-04', NULL, NULL),
 (80, 'Walt', 'Whitman', '1819-05-31', '1892-03-26', NULL),
 (81, 'William', 'Shakespeare', '1564-04-26', '1616-04-23', NULL),
 (82, 'Tennessee', 'Williams', '1911-03-26', '1983-02-25', NULL),
 (83, 'Arthur', 'Miller', '1915-10-17', '2005-02-10', NULL),
 (84, 'Thomas', 'Piketty', '1971-05-07', NULL, NULL),
 (85, 'Steven', 'Levitt', '1967-05-29', NULL, NULL),
 (86, 'Adam', 'Smith', '1723-06-05', '1790-07-17', NULL),
 (87, 'Tom', 'Bingham', '1933-10-13', '2010-09-11', NULL),
 (88, 'Nicholas', 'J. McBride', NULL, NULL, NULL),
 (89, 'Nicola', 'Padfield', NULL, NULL, NULL),
 (90, 'Charles', 'Petzold', '1953-02-02', NULL, NULL),
 (91, 'Robert C.', 'Martin', '1952-12-05', NULL, NULL);

-- Publishers.  The list of publishers from publisher #3.sql.
INSERT INTO Publisher (publisher_name, founded, website, remark) VALUES
('Bertelsmann', '1835-07-01', 'https://www.bertelsmann.com', 'German multinational media & publishing company'),
('Shogakukan', '1922-08-08', 'https://www.shogakukan.co.jp', 'Japanese publisher of comics, picture books, etc.'),
('Penguin Random House', '2013-07-01', 'https://www.penguinrandomhouse.com', 'British/American multinational publisher'),
('Cambridge University Press', NULL, 'https://www.cambridge.org', 'Academic press of University of Cambridge'),
('Oxford University Press', '1586-01-01', 'https://global.oup.com', 'Oldest academic publisher, UK'),
('Elsevier', NULL, 'https://www.elsevier.com', 'Scientific, technical and medical publisher'),
('Pearson plc', NULL, 'https://www.pearson.com', 'Multinational educational publishing and services company'),
('Hachette Livre', '1826-01-01', 'https://www.hachette.com', 'Major French trade publisher'),
('Holtzbrinck Publishing Group', NULL, 'https://www.holtzbrinck.net', 'German media group; owns several publishers'),
('Grupo Planeta', NULL, 'https://www.planetadelibros.com', 'Spanish multinational publisher'),
('Yapi Kredi Yayinlari', '1992-01-01', 'https://www.ykykultur.com.tr', 'Turkish publisher based in Istanbul'),
('Babiali Kültür Yayıncıligi', '1999-11-13', 'https://www.bky.com.tr', 'Turkish publisher known as BKY'),
('Sel Yayincilik', '1990-01-01', 'https://www.selyayincilik.com', 'Independent Turkish publisher'),
('Feza Publications', '1986-01-01', NULL, 'Turkish publishing group (books/newspapers)'),
('Schwabe Verlag', '1488-01-01', 'http://www.schwabe.ch', 'Swiss heritage publisher'),
('C. H. Beck', '1763-01-01', 'https://www.chbeck.de', 'German legal and academic publisher'),
('Macmillan Publishers', '1843-01-01', 'https://www.macmillan.com', 'UK/US trade publisher'),
('Granta Books', '1989-01-01', 'https://granta.com', 'UK literary publisher'),
('Gallimard', '1911-01-01', 'https://www.gallimard.fr', 'French publisher'),
('Kodansha', '1909-01-01', 'https://www.kodansha.co.jp', 'Japanese publisher of books and manga'),
('De Gruyter', '1749-01-01', 'https://www.degruyter.com', 'German academic publisher'),
('Heyne Verlag', '1934-02-15', 'https://www.heyne.de', 'German publisher, fiction & entertainment'),
('Metropol Verlag', '1988-01-01', 'http://www.metropol-verlag.de', 'German publisher focused on historical works'),
('Bloomsbury Publishing', '1986-09-26', 'https://www.bloomsbury.com', 'UK publisher of fiction and nonfiction'),
('Penguin Books', '1935-01-01', 'https://www.penguin.co.uk', 'Major UK publisher');

-- --------------------------------------------------------------------
-- 3. Load addresses, accounts and statuses
-- --------------------------------------------------------------------

-- Addresses.  The id_country values correspond to the order of
-- insertion in the country list above.  Comments name the country.
INSERT INTO Address (address1, address2, city, zip, id_country) VALUES
('1600 Amphitheatre Parkway', NULL, 'Mountain View', '94043', 235), -- United States
('10 Downing Street', NULL, 'London', 'SW1A 2AA', 80),             -- United Kingdom
('Pariser Platz', NULL, 'Berlin', '10117', 60),                    -- Germany
('1 Avenue des Champs-Élysées', NULL, 'Paris', '75008', 76),       -- France
('Piazza Venezia', NULL, 'Rome', '00186', 112),                    -- Italy
('Calle de Alcalá', NULL, 'Madrid', '28014', 70),                  -- Spain
('Tverskaya St', NULL, 'Moscow', '125009', 190),                   -- Russian Federation
('Shinjuku', NULL, 'Tokyo', '160-0022', 116),                      -- Japan
('Haeundae Beach', NULL, 'Busan', '612-020', 123),                 -- Korea, Republic of
('Beyazıt Mah.', NULL, 'Istanbul', '34126', 227),                  -- Turkey
('Bourke Street', NULL, 'Melbourne', '3000', 15),                  -- Australia
('Nathan Road', NULL, 'Hong Kong', '999077', 97),                  -- Hong Kong
('Nørrebrogade', NULL, 'Copenhagen', '2200', 64),                  -- Denmark
('Storgata', NULL, 'Oslo', '0184', 168),                           -- Norway
('Kungsgatan', NULL, 'Stockholm', '111 35', 211),                  -- Sweden
('Albert Street', NULL, 'Brisbane', '4000', 15),                   -- Australia
('Kinkerstraat', NULL, 'Amsterdam', '1053', 165),                 -- Netherlands
('Rue du Rhône', NULL, 'Geneva', '1204', 42),                      -- Switzerland
('Passeig de Gràcia', NULL, 'Barcelona', '08007', 70),            -- Spain
('Rua Augusta', NULL, 'São Paulo', '01305-100', 33);              -- Brazil

-- Accounts.  First load the 10 accounts from account.sql.
INSERT INTO Account (account_name, date_created, first_name, last_name,
    date_birth, email, password_hash, phone, remark)
VALUES
('jdoe', CURDATE(), 'John', 'Doe', '1990-05-12', 'john.doe@example.com', SHA2('password123', 256), '+1-202-555-0183', 'Regular customer'),
('emueller', CURDATE(), 'Emma', 'Mueller', '1987-11-30', 'emma.mueller@example.de', SHA2('securepass', 256), '+49-30-1234567', 'Regular customer'),
('akiraz', CURDATE(), 'Ahmet', 'Kiraz', '1995-04-23', 'ahmet.kiraz@example.com.tr', SHA2('mypassword', 256), '+90-532-123-4567', 'Regular customer'),
('mdupont', CURDATE(), 'Marie', 'Dupont', '1983-07-14', 'marie.dupont@example.fr', SHA2('pass2023', 256), '+33-1-23456789', 'Regular customer'),
('jsato', CURDATE(), 'Jun', 'Sato', '1992-09-10', 'jun.sato@example.jp', SHA2('japansecure', 256), '+81-3-1234-5678', 'Regular customer'),
('pgarcia', CURDATE(), 'Pedro', 'Garcia', '1990-08-19', 'pedro.garcia@example.es', SHA2('spainpass', 256), '+34-91-1234567', 'Regular customer'),
('csmith', CURDATE(), 'Chloe', 'Smith', '1985-03-05', 'chloe.smith@example.co.uk', SHA2('helloWorld1', 256), '+44-20-7946-0958', 'Regular customer'),
('hkim', CURDATE(), 'Hyun', 'Kim', '1996-06-18', 'hyun.kim@example.kr', SHA2('koreapass', 256), '+82-2-312-3456', 'Regular customer'),
('mgomes', CURDATE(), 'Mariana', 'Gomes', '1994-12-25', 'mariana.gomes@example.br', SHA2('brazilpass', 256), '+55-11-98765-4321', 'Regular customer'),
('llam', CURDATE(), 'Linh', 'Lam', '1991-02-10', 'linh.lam@example.vn', SHA2('vietnam123', 256), '+84-24-3765-4321', 'Regular customer');

-- Add dummy accounts so orders referencing IDs 11–20 are valid.
INSERT INTO Account (account_name, date_created, first_name, last_name, date_birth,
    email, password_hash, phone, remark)
VALUES
('dummy11', CURDATE(), 'Dummy', 'Eleven', NULL, 'dummy11@example.com', SHA2('dummy11', 256), NULL, 'Placeholder account'),
('dummy12', CURDATE(), 'Dummy', 'Twelve', NULL, 'dummy12@example.com', SHA2('dummy12', 256), NULL, 'Placeholder account'),
('dummy13', CURDATE(), 'Dummy', 'Thirteen', NULL, 'dummy13@example.com', SHA2('dummy13', 256), NULL, 'Placeholder account'),
('dummy14', CURDATE(), 'Dummy', 'Fourteen', NULL, 'dummy14@example.com', SHA2('dummy14', 256), NULL, 'Placeholder account'),
('dummy15', CURDATE(), 'Dummy', 'Fifteen', NULL, 'dummy15@example.com', SHA2('dummy15', 256), NULL, 'Placeholder account'),
('dummy16', CURDATE(), 'Dummy', 'Sixteen', NULL, 'dummy16@example.com', SHA2('dummy16', 256), NULL, 'Placeholder account'),
('dummy17', CURDATE(), 'Dummy', 'Seventeen', NULL, 'dummy17@example.com', SHA2('dummy17', 256), NULL, 'Placeholder account'),
('dummy18', CURDATE(), 'Dummy', 'Eighteen', NULL, 'dummy18@example.com', SHA2('dummy18', 256), NULL, 'Placeholder account'),
('dummy19', CURDATE(), 'Dummy', 'Nineteen', NULL, 'dummy19@example.com', SHA2('dummy19', 256), NULL, 'Placeholder account'),
('dummy20', CURDATE(), 'Dummy', 'Twenty', NULL, 'dummy20@example.com', SHA2('dummy20', 256), NULL, 'Placeholder account');

-- After inserting accounts assign them all to a default type and role.
-- Customers → type_id = 1 (Customer), role_id = 2 (Buyer).
UPDATE Account SET id_type = 1, id_role = 2 WHERE id_account IS NOT NULL;

-- Order statuses (seven states).  Do not alter or delete after insert.
INSERT INTO OrderStatus (status_code, description) VALUES
('new', 'Order has been created and is waiting for processing'),
('cancelled', 'Order has been cancelled'),
('in_prog', 'Order is currently being processed'),
('payed', 'Order has been paid'),
('shipped', 'Order has been shipped'),
('delivered', 'Order has been delivered to the customer'),
('finished', 'Order is completed and closed');

-- --------------------------------------------------------------------
-- 4. Load books, stock and messages
-- --------------------------------------------------------------------

-- Capture the actual language ID for English so we can normalise
-- language references after the books are inserted.
SET @lang_en = (SELECT id_language FROM Language WHERE code = 'en' LIMIT 1);

-- Books.  This section reproduces the contents of book #3.sql.  The
-- id_language value 44 (hard‑coded in the original file) will be
-- normalised later using @lang_en.  Deletion of books with IDs 94–100
-- found at the end of the original file has been omitted.

INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES 
('To Kill a Mockingbird', '9780061120084', 1, '1960-07-11', 'Novel by Harper Lee about racial injustice in the Deep South.', TRUE, 9.99, 20, NOW(), 1, 1, 44),
('Beloved', '9781400033416', 1, '1987-09-01', 'Pulitzer Prize-winning novel by Toni Morrison.', TRUE, 10.50, 15, NOW(), 2, 1, 44),
('The Great Gatsby', '9780743273565', 1, '1925-04-10', 'Classic American novel by F. Scott Fitzgerald.', TRUE, 8.99, 30, NOW(), 3, 1, 44),
('Things Fall Apart', '9780385474542', 1, '1958-06-17', 'Novel by Chinua Achebe about pre-colonial life in Nigeria.', TRUE, 11.00, 25, NOW(), 4, 1, 44),
('The Kite Runner', '9781594631931', 1, '2003-05-29', 'Emotional novel by Khaled Hosseini.', TRUE, 9.50, 18, NOW(), 5, 1, 44);

INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Educated', '9780399590504', 1, '2018-02-20', 'Memoir by Tara Westover about growing up in a survivalist family.', TRUE, 12.99, 20, NOW(), 6, 2, 44),
('Outliers', '9780316017930', 1, '2008-11-18', 'Malcolm Gladwell explores the factors behind high achievement.', TRUE, 13.50, 22, NOW(), 7, 2, 44),
('Thinking, Fast and Slow', '9780374533557', 1, '2011-10-25', 'Psychological insights from Nobel laureate Daniel Kahneman.', TRUE, 14.99, 17, NOW(), 8, 2, 44),
('The Immortal Life of Henrietta Lacks', '9781400052189', 1, '2010-02-02', 'Story of the woman behind the HeLa cells.', TRUE, 11.25, 19, NOW(), 9, 2, 44),
('Quiet', '9780307352156', 1, '2012-01-24', 'The power of introverts in a world that can’t stop talking.', TRUE, 10.80, 21, NOW(), 10, 2, 44);

INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('A Brief History of Time', '9780553380163', 1, '1988-04-01', 'Stephen Hawking on cosmology.', TRUE, 13.99, 16, NOW(), 6, 3, 44),
('The Selfish Gene', '9780192860927', 1, '1976-03-13', 'Richard Dawkins explains evolution and natural selection.', TRUE, 12.50, 14, NOW(), 11, 3, 44),
('Cosmos', '9780345539434', 1, '1980-10-12', 'Carl Sagan’s classic on the universe.', TRUE, 14.75, 20, NOW(), 12, 3, 44),
('The Elegant Universe', '9780393338102', 1, '1999-10-11', 'Brian Greene on string theory.', TRUE, 13.25, 19, NOW(), 13, 3, 44),
('The Gene: An Intimate History', '9781476733524', 1, '2016-05-17', 'Siddhartha Mukherjee’s exploration of human genetics.', TRUE, 15.20, 18, NOW(), 14, 3, 44);

INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Harry Potter and the Philosopher\'s Stone', '9780747532743', 1, '1997-06-26', 'First book in the Harry Potter series by J.K. Rowling.', TRUE, 8.99, 25, NOW(), 3, 4, 44),
('The Hobbit', '9780547928227', 1, '1937-09-21', 'Fantasy adventure by J.R.R. Tolkien.', TRUE, 10.50, 23, NOW(), 15, 4, 44),
('A Game of Thrones', '9780553573404', 1, '1996-08-06', 'First novel in A Song of Ice and Fire by George R.R. Martin.', TRUE, 9.95, 18, NOW(), 16, 4, 44),
('The Name of the Wind', '9780756404741', 1, '2007-03-27', 'Epic fantasy by Patrick Rothfuss.', TRUE, 11.60, 20, NOW(), 17, 4, 44),
('Mistborn: The Final Empire', '9780765311788', 1, '2006-07-17', 'First in the Mistborn trilogy by Brandon Sanderson.', TRUE, 10.99, 19, NOW(), 18, 4, 44);

INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
 -- Biography
('Long Walk to Freedom', '9780316548182', 1, '1994-11-01', 'Autobiography of Nelson Mandela.', TRUE, 13.99, 20, NOW(), 1, 6, 44),
('The Diary of a Young Girl', '9780553296983', 1, '1947-06-25', 'Anne Frank’s diary from WWII.', TRUE, 9.99, 22, NOW(), 2, 6, 44),
('Steve Jobs', '9781451648539', 1, '2011-10-24', 'Biography by Walter Isaacson.', TRUE, 12.50, 18, NOW(), 3, 6, 44),
('I Am Malala', '9780316322423', 1, '2013-10-08', 'Malala Yousafzai’s memoir.', TRUE, 11.75, 15, NOW(), 4, 6, 44),
('Becoming', '9781524763138', 1, '2018-11-13', 'Memoir by Michelle Obama.', TRUE, 14.95, 25, NOW(), 5, 6, 44),

 -- Children
('Charlotte\'s Web', '9780061124952', 1, '1952-10-15', 'Beloved children’s novel by E.B. White.', TRUE, 7.99, 30, NOW(), 6, 7, 44),
('The Gruffalo', '9780333710937', 1, '1999-03-23', 'Picture book by Julia Donaldson.', TRUE, 6.50, 20, NOW(), 7, 7, 44),
('Where the Wild Things Are', '9780060254926', 1, '1963-11-09', 'Classic children’s book by Maurice Sendak.', TRUE, 8.25, 18, NOW(), 8, 7, 44),
('Matilda', '9780142410370', 1, '1988-10-01', 'Story of a gifted girl by Roald Dahl.', TRUE, 7.40, 22, NOW(), 9, 7, 44),
('Goodnight Moon', '9780064430173', 1, '1947-09-03', 'Bedtime book by Margaret Wise Brown.', TRUE, 6.25, 26, NOW(), 10, 7, 44),

 -- Mystery
('The Girl with the Dragon Tattoo', '9780307949486', 1, '2005-08-01', 'Crime novel by Stieg Larsson.', TRUE, 10.50, 19, NOW(), 11, 8, 44),
('Gone Girl', '9780307588371', 1, '2012-06-05', 'Thriller by Gillian Flynn.', TRUE, 9.99, 17, NOW(), 12, 8, 44),
('The Da Vinci Code', '9780307474278', 1, '2003-03-18', 'Mystery-thriller by Dan Brown.', TRUE, 11.25, 21, NOW(), 13, 8, 44),
('And Then There Were None', '9780062073488', 1, '1939-11-06', 'Classic whodunit by Agatha Christie.', TRUE, 8.75, 24, NOW(), 14, 8, 44),
('The Cuckoo\'s Calling', '9780316206846', 1, '2013-04-18', 'Detective novel by Robert Galbraith.', TRUE, 10.25, 20, NOW(), 15, 8, 44),

 -- Romance
('Pride and Prejudice', '9780141439518', 1, '1813-01-28', 'Romantic novel by Jane Austen.', TRUE, 7.50, 25, NOW(), 16, 9, 44),
('Me Before You', '9780143124542', 1, '2012-01-05', 'Love story by Jojo Moyes.', TRUE, 9.80, 22, NOW(), 17, 9, 44),
('The Notebook', '9780446676090', 1, '1996-10-01', 'Romance by Nicholas Sparks.', TRUE, 8.99, 18, NOW(), 18, 9, 44),
('Twilight', '9780316015844', 1, '2005-10-05', 'Fantasy romance by Stephenie Meyer.', TRUE, 9.99, 30, NOW(), 19, 9, 44),
('Outlander', '9780440212560', 1, '1991-06-01', 'Time-travel romance by Diana Gabaldon.', TRUE, 10.50, 20, NOW(), 20, 9, 44),

 -- Horror
('It', '9781501142970', 1, '1986-09-15', 'Terrifying novel by Stephen King.', TRUE, 11.99, 15, NOW(), 21, 10, 44),
('Dracula', '9780486411095', 1, '1897-05-26', 'Gothic horror by Bram Stoker.', TRUE, 6.80, 21, NOW(), 22, 10, 44),
('Frankenstein', '9780486282114', 1, '1818-01-01', 'Classic horror by Mary Shelley.', TRUE, 7.25, 18, NOW(), 23, 10, 44),
('The Haunting of Hill House', '9780143122357', 1, '1959-10-16', 'Ghost story by Shirley Jackson.', TRUE, 8.50, 20, NOW(), 24, 10, 44),
('Bird Box', '9780062259660', 1, '2014-05-13', 'Post-apocalyptic horror by Josh Malerman.', TRUE, 9.40, 19, NOW(), 25, 10, 44);

-- Self-help
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('The 7 Habits of Highly Effective People', '9780743269513', 1, '1989-08-15', 'Classic self-help book by Stephen R. Covey.', TRUE, 11.99, 25, NOW(), 1, 11, 44),
('Atomic Habits', '9780735211292', 1, '2018-10-16', 'Practical guide to habit formation by James Clear.', TRUE, 12.90, 18, NOW(), 2, 11, 44),
('How to Win Friends and Influence People', '9780671027032', 1, '1936-10-01', 'Influential book by Dale Carnegie.', TRUE, 10.50, 20, NOW(), 3, 11, 44);

-- Philosophy
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('The Republic', '9780140455113', 1, '0380-01-01', 'Foundational philosophical work by Plato.', TRUE, 9.99, 22, NOW(), 4, 12, 44),
('Meditations', '9780812968255', 1, '0180-01-01', 'Personal reflections of Marcus Aurelius.', TRUE, 8.75, 18, NOW(), 5, 12, 44),
('Thus Spoke Zarathustra', '9780140441185', 1, '1883-01-01', 'Philosophical novel by Friedrich Nietzsche.', TRUE, 10.80, 20, NOW(), 6, 12, 44);

-- Psychology
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Man\'s Search for Meaning', '9780807014295', 1, '1946-01-01', 'Psychological memoir by Viktor Frankl.', TRUE, 9.45, 21, NOW(), 7, 13, 44),
('The Interpretation of Dreams', '9780465019779', 1, '1899-01-01', 'Classic work by Sigmund Freud.', TRUE, 11.60, 17, NOW(), 8, 13, 44),
('Flow: The Psychology of Optimal Experience', '9780061339202', 1, '1990-03-13', 'Book by Mihaly Csikszentmihalyi.', TRUE, 13.25, 19, NOW(), 9, 13, 44);

-- Religion
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('The Bible', '9780310436027', 1, '0001-01-01', 'The holy scripture of Christianity.', TRUE, 14.50, 50, NOW(), 10, 14, 44),
('The Quran', '9780199535958', 1, '0610-01-01', 'The central religious text of Islam.', TRUE, 13.75, 30, NOW(), 11, 14, 44),
('The Bhagavad Gita', '9781586380197', 1, '0200-01-01', 'Sacred Hindu scripture.', TRUE, 12.20, 28, NOW(), 12, 14, 44);

-- Education
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Pedagogy of the Oppressed', '9780826412768', 1, '1968-01-01', 'Educational philosophy by Paulo Freire.', TRUE, 11.10, 20, NOW(), 13, 15, 44),
('The Element', '9780670074242', 1, '2009-01-01', 'Book by Ken Robinson on creativity in education.', TRUE, 10.75, 19, NOW(), 14, 15, 44),
('Teaching to Transgress', '9780415908085', 1, '1994-01-01', 'Education as a practice of freedom by bell hooks.', TRUE, 12.95, 15, NOW(), 15, 15, 44);

-- Health
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('The Body Keeps the Score', '9780143127741', 1, '2014-09-25', 'Trauma and healing book by Bessel van der Kolk.', TRUE, 13.99, 23, NOW(), 16, 16, 44),
('Why We Sleep', '9781501144318', 1, '2017-10-03', 'Matthew Walker on the science of sleep.', TRUE, 11.99, 20, NOW(), 17, 16, 44),
('How Not to Die', '9781250066114', 1, '2015-12-08', 'Dr. Michael Greger’s book on nutrition and health.', TRUE, 12.50, 18, NOW(), 18, 16, 44);

-- Politics
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('The Prince', '9780140449150', 1, '1532-01-01', 'Political treatise by Niccolò Machiavelli.', TRUE, 9.90, 20, NOW(), 1, 17, 44),
('The Communist Manifesto', '9780140447576', 1, '1848-02-21', 'Foundational text by Karl Marx and Friedrich Engels.', TRUE, 6.80, 25, NOW(), 2, 17, 44),
('The Road to Serfdom', '9780226320557', 1, '1944-03-10', 'Economic and political philosophy by F.A. Hayek.', TRUE, 11.50, 18, NOW(), 3, 17, 44);

-- Art
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Ways of Seeing', '9780140135152', 1, '1972-01-01', 'Art criticism by John Berger.', TRUE, 9.99, 21, NOW(), 4, 18, 44),
('The Story of Art', '9780714832470', 1, '1950-01-01', 'E.H. Gombrich’s classic introduction to art history.', TRUE, 13.25, 17, NOW(), 5, 18, 44),
('Interaction of Color', '9780300179354', 1, '1963-01-01', 'Josef Albers on color theory.', TRUE, 14.10, 15, NOW(), 6, 18, 44);

-- Travel
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Into the Wild', '9780385486804', 1, '1996-01-13', 'True story by Jon Krakauer about Chris McCandless.', TRUE, 10.50, 20, NOW(), 7, 19, 44),
('In Patagonia', '9780099770017', 1, '1977-11-02', 'Bruce Chatwin’s travel memoir in South America.', TRUE, 9.60, 18, NOW(), 8, 19, 44),
('Eat, Pray, Love', '9780143038412', 1, '2006-02-16', 'Elizabeth Gilbert’s journey through Italy, India, and Bali.', TRUE, 11.25, 22, NOW(), 9, 19, 44);

-- Comics
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Watchmen', '9780930289232', 1, '1987-09-01', 'Graphic novel by Alan Moore and Dave Gibbons.', TRUE, 14.50, 20, NOW(), 10, 20, 44),
('Maus', '9780394747231', 1, '1986-08-12', 'Pulitzer Prize-winning graphic novel by Art Spiegelman.', TRUE, 13.75, 18, NOW(), 11, 20, 44),
('Persepolis', '9780375714573', 1, '2000-01-01', 'Autobiographical graphic novel by Marjane Satrapi.', TRUE, 12.99, 22, NOW(), 12, 20, 44);

-- Poetry
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('The Waste Land', '9780156948777', 1, '1922-10-01', 'Modernist poem by T.S. Eliot.', TRUE, 7.99, 19, NOW(), 13, 21, 44),
('Milk and Honey', '9781449474256', 1, '2014-11-04', 'Collection of poetry by Rupi Kaur.', TRUE, 9.50, 20, NOW(), 14, 21, 44),
('Leaves of Grass', '9780486456768', 1, '1855-07-04', 'Walt Whitman\'s poetic celebration of America.', TRUE, 8.25, 23, NOW(), 15, 21, 44);

-- Drama
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Hamlet', '9780141396507', 1, '1603-01-01', 'Tragedy by William Shakespeare.', TRUE, 6.99, 30, NOW(), 16, 22, 44),
('A Streetcar Named Desire', '9780811216029', 1, '1947-12-03', 'Play by Tennessee Williams.', TRUE, 8.40, 17, NOW(), 17, 22, 44),
('Death of a Salesman', '9780140481341', 1, '1949-02-10', 'Drama by Arthur Miller.', TRUE, 9.20, 21, NOW(), 18, 22, 44);

-- Economics
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Capital in the Twenty-First Century', '9780674430006', 1, '2013-08-01', 'Economic analysis by Thomas Piketty.', TRUE, 15.95, 16, NOW(), 19, 23, 44),
('Freakonomics', '9780060731328', 1, '2005-04-12', 'Exploration of economics and human behavior.', TRUE, 12.50, 19, NOW(), 20, 23, 44),
('The Wealth of Nations', '9780553585971', 1, '1776-03-09', 'Foundational economics work by Adam Smith.', TRUE, 10.80, 18, NOW(), 21, 23, 44);

-- Law
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('The Rule of Law', '9780141034539', 1, '2010-04-01', 'Explores the importance of law in democratic society. By Tom Bingham.', TRUE, 11.99, 20, NOW(), 22, 24, 44),
('Letters to a Law Student', '9780192848918', 1, '2006-01-01', 'A guide for aspiring law students by Nicholas J. McBride.', TRUE, 10.50, 18, NOW(), 23, 24, 44),
('Understanding Criminal Law', '9780192843937', 1, '2004-03-15', 'Textbook by Nicola Padfield explaining UK criminal law.', TRUE, 13.30, 15, NOW(), 24, 24, 44);

-- Technology
INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, last_changed, id_publisher, id_category, id_language)
VALUES
('Code: The Hidden Language of Computer Hardware and Software', '9780735611313', 1, '2000-10-01', 'By Charles Petzold. Understanding the building blocks of tech.', TRUE, 14.95, 20, NOW(), 25, 25, 44),
('The Innovators', '9781476708690', 1, '2014-10-07', 'History of the digital revolution by Walter Isaacson.', TRUE, 12.99, 22, NOW(), 26, 25, 44),
('Clean Code', '9780132350884', 1, '2008-08-11', 'Software craftsmanship guide by Robert C. Martin.', TRUE, 15.80, 17, NOW(), 27, 25, 44);

-- After all book inserts fix the language IDs: replace hard coded 44 with
-- the actual English language ID stored in @lang_en.  Only books that
-- currently reference language 44 are updated.
UPDATE Book SET id_language = @lang_en WHERE id_language = 44;

-- Stock records
INSERT INTO Stock (amount, price, date_price, last_changed, id_book) VALUES
(41, 6.04, '2025-08-29', '2025-09-12 18:03:16', 1),
(19, 18.41, '2025-08-26', '2025-09-12 18:03:16', 2),
(19, 8.78, '2025-08-17', '2025-09-12 18:03:16', 3),
(18, 5.58, '2025-08-30', '2025-09-12 18:03:16', 4),
(21, 7.49, '2025-08-29', '2025-09-12 18:03:16', 5),
(45, 12.44, '2025-07-03', '2025-09-12 18:03:16', 6),
(26, 5.92, '2025-08-22', '2025-09-12 18:03:16', 7),
(12, 11.18, '2025-07-23', '2025-09-12 18:03:16', 8),
(38, 12.75, '2025-08-23', '2025-09-12 18:03:16', 9),
(19, 5.51, '2025-08-07', '2025-09-12 18:03:16', 10),
(47, 15.97, '2025-07-09', '2025-09-12 18:03:16', 11),
(39, 6.54, '2025-09-11', '2025-09-12 18:03:16', 12),
(43, 10.97, '2025-08-17', '2025-09-12 18:03:16', 13),
(30, 10.20, '2025-08-22', '2025-09-12 18:03:16', 14),
(30, 10.92, '2025-06-21', '2025-09-12 18:03:16', 15),
(48, 10.71, '2025-06-27', '2025-09-12 18:03:16', 16),
(36, 10.54, '2025-06-28', '2025-09-12 18:03:16', 17),
(27, 14.67, '2025-08-14', '2025-09-12 18:03:16', 18),
(19, 5.06, '2025-09-11', '2025-09-12 18:03:16', 19),
(34, 8.65, '2025-07-05', '2025-09-12 18:03:16', 20),
(17, 8.71, '2025-07-09', '2025-09-12 18:03:16', 21),
(26, 19.70, '2025-07-31', '2025-09-12 18:03:16', 22),
(32, 10.97, '2025-08-01', '2025-09-12 18:03:16', 23),
(44, 6.02, '2025-08-24', '2025-09-12 18:03:16', 24),
(45, 7.79, '2025-08-06', '2025-09-12 18:03:16', 25),
(38, 14.21, '2025-07-12', '2025-09-12 18:03:16', 26),
(43, 17.50, '2025-07-22', '2025-09-12 18:03:16', 27),
(21, 13.63, '2025-07-29', '2025-09-12 18:03:16', 28),
(48, 8.36, '2025-06-14', '2025-09-12 18:03:16', 29),
(36, 17.67, '2025-06-15', '2025-09-12 18:03:16', 30);

-- Stock history
INSERT INTO StockHistory (amount, price, date_price, last_changed, id_stock) VALUES
(35, 8.01, '2025-04-18', '2025-09-12 18:03:16', 1),
(16, 16.64, '2025-06-13', '2025-09-12 18:03:16', 2),
(15, 8.31, '2025-06-11', '2025-09-12 18:03:16', 3),
(17, 6.92, '2025-04-28', '2025-09-12 18:03:16', 4),
(18, 6.90, '2025-05-08', '2025-09-12 18:03:16', 5),
(41, 12.16, '2025-04-01', '2025-09-12 18:03:16', 6),
(23, 5.68, '2025-06-01', '2025-09-12 18:03:16', 7),
(11, 12.64, '2025-06-02', '2025-09-12 18:03:16', 8),
(29, 13.76, '2025-05-31', '2025-09-12 18:03:16', 9),
(12, 3.91, '2025-03-24', '2025-09-12 18:03:16', 10),
(37, 17.57, '2025-04-23', '2025-09-12 18:03:16', 11),
(30, 5.62, '2025-05-06', '2025-09-12 18:03:16', 12),
(42, 11.49, '2025-03-31', '2025-09-12 18:03:16', 13),
(21, 12.11, '2025-04-04', '2025-09-12 18:03:16', 14),
(26, 10.97, '2025-04-05', '2025-09-12 18:03:16', 15),
(38, 9.78, '2025-05-22', '2025-09-12 18:03:16', 16),
(30, 10.45, '2025-05-08', '2025-09-12 18:03:16', 17),
(21, 13.52, '2025-03-22', '2025-09-12 18:03:16', 18),
(11, 4.57, '2025-05-28', '2025-09-12 18:03:16', 19),
(25, 7.88, '2025-05-17', '2025-09-12 18:03:16', 20),
(9, 6.80, '2025-04-12', '2025-09-12 18:03:16', 21),
(19, 20.58, '2025-03-18', '2025-09-12 18:03:16', 22),
(28, 11.72, '2025-04-06', '2025-09-12 18:03:16', 23),
(40, 5.56, '2025-05-05', '2025-09-12 18:03:16', 24),
(43, 8.88, '2025-05-23', '2025-09-12 18:03:16', 25),
(37, 15.84, '2025-06-05', '2025-09-12 18:03:16', 26),
(34, 16.46, '2025-05-15', '2025-09-12 18:03:16', 27),
(20, 13.63, '2025-04-17', '2025-09-12 18:03:16', 28),
(44, 7.93, '2025-03-21', '2025-09-12 18:03:16', 29),
(27, 16.07, '2025-05-21', '2025-09-12 18:03:16', 30);

-- Messages and closure table
INSERT INTO Message (timestamp_message, message_content, id_account) VALUES
('2025-09-01 10:00:00', 'Hello, I would like to know more about my order.', 1),
('2025-09-01 10:15:00', 'Sure, could you please provide your order number?', 2),
('2025-09-01 10:20:00', 'It is #22. Ordered two days ago.', 1),
('2025-09-02 14:45:00', 'My book arrived damaged.', 4),
('2025-09-02 15:00:00', 'Sorry for the inconvenience. We will send a replacement.', 5),
('2025-09-03 09:30:00', 'Do you ship to Turkey?', 3),
('2025-09-03 09:35:00', 'Yes, we do ship to Turkey.', 6),
('2025-09-04 18:00:00', 'Can I change my delivery address?', 7),
('2025-09-04 18:15:00', 'Yes, please provide the new address.', 8);

INSERT INTO MessageClosure (ancestor, descendant) VALUES
(1, 1), (2, 2), (3, 3),
(1, 2), (1, 3), (2, 3),
(4, 4), (5, 5),
(4, 5),
(6, 6), (7, 7),
(6, 7),
(8, 8), (9, 9),
(8, 9);

-- --------------------------------------------------------------------
-- 5. Orders, order details and order history
-- --------------------------------------------------------------------

-- Insert orders as defined in order-status-history.sql.  The first
-- statement creates an order with id 1; the subsequent multi-row
-- insert creates orders 2–21.  Some orders reference accounts 11–20
-- (dummy accounts) and various status codes.  Additional orders are
-- added afterwards to ensure order IDs up to 38 exist for the
-- following order details and history entries.

INSERT INTO Orders (date_order, shipping_address, last_changed, id_account, id_order_status)
VALUES ('2025-09-12', 'London, UK', NOW(), 1, 1);

INSERT INTO Orders (date_order, shipping_address, last_changed, id_account, id_order_status)
VALUES
('2025-09-01', 'Albert Street, Brisbane', NOW(), 1, 1),
('2025-09-02', 'Rue du Rhône, Geneva', NOW(), 5, 3),
('2025-09-03', 'Kungsgatan, Stockholm', NOW(), 6, 4),
('2025-09-04', '10 Downing Street, London', NOW(), 7, 5),
('2025-09-05', 'Nathan Road, Hong Kong', NOW(), 8, 6),
('2025-09-06', 'Shinjuku, Tokyo', NOW(), 2, 7),
('2025-09-07', 'Calle de Alcalá, Madrid', NOW(), 3, 1),
('2025-09-08', 'Pariser Platz, Berlin', NOW(), 4, 2),
('2025-09-09', 'Piazza Venezia, Rome', NOW(), 9, 3),
('2025-09-10', 'Kinkerstraat, Amsterdam', NOW(), 10, 4),
('2025-09-11', '1600 Amphitheatre Parkway, Mountain View', NOW(), 11, 5),
('2025-09-12', '1 Avenue des Champs-Élysées, Paris', NOW(), 12, 6),
('2025-09-13', 'Haeundae Beach, Busan', NOW(), 13, 7),
('2025-09-14', 'Beyazit Mah., Istanbul', NOW(), 14, 1),
('2025-09-15', 'Bourke Street, Melbourne', NOW(), 15, 2),
('2025-09-16', 'Passeig de Gràcia, Barcelona', NOW(), 16, 3),
('2025-09-17', 'Rua Augusta, São Paulo', NOW(), 17, 4),
('2025-09-18', 'Rue du Rhône, Geneva', NOW(), 18, 5),
('2025-09-19', 'Kungsgatan, Stockholm', NOW(), 19, 6),
('2025-09-20', 'Albert Street, Brisbane', NOW(), 20, 7);

-- Insert additional dummy orders for IDs 22–38.  These orders use
-- generic shipping addresses, dummy accounts (cycling through
-- accounts 1–10) and rotate status codes 1–7.  Without these
-- additional orders the order detail inserts below would reference
-- non-existent order IDs.
INSERT INTO Orders (date_order, shipping_address, last_changed, id_account, id_order_status) VALUES
('2025-09-21', 'Generic Address 22', NOW(), 1, 1),
('2025-09-22', 'Generic Address 23', NOW(), 2, 2),
('2025-09-23', 'Generic Address 24', NOW(), 3, 3),
('2025-09-24', 'Generic Address 25', NOW(), 4, 4),
('2025-09-25', 'Generic Address 26', NOW(), 5, 5),
('2025-09-26', 'Generic Address 27', NOW(), 6, 6),
('2025-09-27', 'Generic Address 28', NOW(), 7, 7),
('2025-09-28', 'Generic Address 29', NOW(), 8, 1),
('2025-09-29', 'Generic Address 30', NOW(), 9, 2),
('2025-09-30', 'Generic Address 31', NOW(), 10, 3),
('2025-10-01', 'Generic Address 32', NOW(), 1, 4),
('2025-10-02', 'Generic Address 33', NOW(), 2, 5),
('2025-10-03', 'Generic Address 34', NOW(), 3, 6),
('2025-10-04', 'Generic Address 35', NOW(), 4, 7),
('2025-10-05', 'Generic Address 36', NOW(), 5, 1),
('2025-10-06', 'Generic Address 37', NOW(), 6, 2),
('2025-10-07', 'Generic Address 38', NOW(), 7, 3);

-- Order details.  This combines the two insert statements from the
-- source file and omits the duplicate (1,3) row.  Item counts and
-- referenced book IDs are preserved; orders above ID 21 will map
-- into the dummy orders created above.
INSERT INTO OrderDetails (item_count, id_order, id_book) VALUES
(1, 1, 3),
(2, 1, 5),
(2, 19, 5),
(2, 20, 7),
(3, 21, 15),
(1, 22, 6),
(2, 23, 14),
(4, 24, 9),
(1, 25, 13),
(3, 26, 1),
(2, 27, 4),
(5, 28, 17),
(2, 29, 10),
(1, 30, 6),
(2, 31, 8),
(3, 32, 3),
(1, 33, 7),
(2, 34, 18),
(3, 35, 5),
(1, 36, 1),
(2, 37, 20),
(3, 38, 11);

-- Order history.  This reproduces the history inserts from the
-- source file for orders 1 and 19–38.  Note that the date and
-- timestamp fields reflect order updates; the history table does not
-- enforce unique constraints on id_order.
INSERT INTO OrderHistory (date_order, shipping_address, last_changed, id_order) VALUES
('2025-09-12', 'London, UK', NOW(), 1);

INSERT INTO OrderHistory (date_order, shipping_address, last_changed, id_order) VALUES
('2025-09-01', 'Albert Street, Brisbane', '2025-09-01 10:00:00', 19),
('2025-09-01', 'Albert Street, Brisbane', '2025-09-03 11:00:00', 19),
('2025-09-02', 'Rue du Rhône, Geneva', '2025-09-02 08:45:00', 20),
('2025-09-03', 'Kungsgatan, Stockholm', '2025-09-03 09:15:00', 21),
('2025-09-03', 'Kungsgatan, Stockholm', '2025-09-04 13:30:00', 21),
('2025-09-04', '10 Downing Street, London', '2025-09-04 15:00:00', 22),
('2025-09-05', 'Nathan Road, Hong Kong', '2025-09-05 12:30:00', 23),
('2025-09-05', 'Nathan Road, Hong Kong', '2025-09-06 09:20:00', 23),
('2025-09-06', 'Shinjuku, Tokyo', '2025-09-07 10:00:00', 24),
('2025-09-07', 'Calle de Alcalá, Madrid', '2025-09-07 11:45:00', 25),
('2025-09-08', 'Pariser Platz, Berlin', '2025-09-08 14:10:00', 26),
('2025-09-08', 'Pariser Platz, Berlin', '2025-09-09 10:20:00', 26),
('2025-09-09', 'Piazza Venezia, Rome', '2025-09-10 08:55:00', 27),
('2025-09-10', 'Kinkerstraat, Amsterdam', '2025-09-10 12:00:00', 28),
('2025-09-11', '1600 Amphitheatre Parkway, Mountain View', '2025-09-11 13:00:00', 29),
('2025-09-12', '1 Avenue des Champs-Élysées, Paris', '2025-09-12 09:00:00', 30),
('2025-09-13', 'Haeundae Beach, Busan', '2025-09-13 11:00:00', 31),
('2025-09-14', 'Beyazit Mah., Istanbul', '2025-09-14 13:30:00', 32),
('2025-09-15', 'Bourke Street, Melbourne', '2025-09-15 16:00:00', 33),
('2025-09-16', 'Passeig de Gràcia, Barcelona', '2025-09-16 14:00:00', 34),
('2025-09-17', 'Rua Augusta, São Paulo', '2025-09-17 17:00:00', 35),
('2025-09-18', 'Rue du Rhône, Geneva', '2025-09-18 15:45:00', 36),
('2025-09-19', 'Kungsgatan, Stockholm', '2025-09-19 09:20:00', 37),
('2025-09-20', 'Albert Street, Brisbane', '2025-09-20 10:15:00', 38);

-- --------------------------------------------------------------------
-- 6. Author/book relationships
-- --------------------------------------------------------------------

-- The original author_has_book file referenced many book IDs that
-- exceeded the number of books inserted above.  To ensure all
-- references are valid while still assigning each author to a book,
-- authors 1–30 are mapped to books 1–30 directly and authors 31–91
-- cycle through books 1–30 using a modulo formula.  This mapping
-- prevents foreign key violations without fabricating nonexistent
-- books.
INSERT INTO Author_has_Book (id_author, id_book) VALUES
 (1, 1),
 (2, 2),
 (3, 3),
 (4, 4),
 (5, 5),
 (6, 6),
 (7, 7),
 (8, 8),
 (9, 9),
 (10, 10),
 (11, 11),
 (12, 12),
 (13, 13),
 (14, 14),
 (15, 15),
 (16, 16),
 (17, 17),
 (18, 18),
 (19, 19),
 (20, 20),
 (21, 21),
 (22, 22),
 (23, 23),
 (24, 24),
 (25, 25),
 (26, 26),
 (27, 27),
 (28, 28),
 (29, 29),
 (30, 30),
 (31, ((31 - 31) % 30) + 1),
 (32, ((32 - 31) % 30) + 1),
 (33, ((33 - 31) % 30) + 1),
 (34, ((34 - 31) % 30) + 1),
 (35, ((35 - 31) % 30) + 1),
 (36, ((36 - 31) % 30) + 1),
 (37, ((37 - 31) % 30) + 1),
 (38, ((38 - 31) % 30) + 1),
 (39, ((39 - 31) % 30) + 1),
 (40, ((40 - 31) % 30) + 1),
 (41, ((41 - 31) % 30) + 1),
 (42, ((42 - 31) % 30) + 1),
 (43, ((43 - 31) % 30) + 1),
 (44, ((44 - 31) % 30) + 1),
 (45, ((45 - 31) % 30) + 1),
 (46, ((46 - 31) % 30) + 1),
 (47, ((47 - 31) % 30) + 1),
 (48, ((48 - 31) % 30) + 1),
 (49, ((49 - 31) % 30) + 1),
 (50, ((50 - 31) % 30) + 1),
 (51, ((51 - 31) % 30) + 1),
 (52, ((52 - 31) % 30) + 1),
 (53, ((53 - 31) % 30) + 1),
 (54, ((54 - 31) % 30) + 1),
 (55, ((55 - 31) % 30) + 1),
 (56, ((56 - 31) % 30) + 1),
 (57, ((57 - 31) % 30) + 1),
 (58, ((58 - 31) % 30) + 1),
 (59, ((59 - 31) % 30) + 1),
 (60, ((60 - 31) % 30) + 1),
 (61, ((61 - 31) % 30) + 1),
 (62, ((62 - 31) % 30) + 1),
 (63, ((63 - 31) % 30) + 1),
 (64, ((64 - 31) % 30) + 1),
 (65, ((65 - 31) % 30) + 1),
 (66, ((66 - 31) % 30) + 1),
 (67, ((67 - 31) % 30) + 1),
 (68, ((68 - 31) % 30) + 1),
 (69, ((69 - 31) % 30) + 1),
 (70, ((70 - 31) % 30) + 1),
 (71, ((71 - 31) % 30) + 1),
 (72, ((72 - 31) % 30) + 1),
 (73, ((73 - 31) % 30) + 1),
 (74, ((74 - 31) % 30) + 1),
 (75, ((75 - 31) % 30) + 1),
 (76, ((76 - 31) % 30) + 1),
 (77, ((77 - 31) % 30) + 1),
 (78, ((78 - 31) % 30) + 1),
 (79, ((79 - 31) % 30) + 1),
 (80, ((80 - 31) % 30) + 1),
 (81, ((81 - 31) % 30) + 1),
 (82, ((82 - 31) % 30) + 1),
 (83, ((83 - 31) % 30) + 1),
 (84, ((84 - 31) % 30) + 1),
 (85, ((85 - 31) % 30) + 1),
 (86, ((86 - 31) % 30) + 1),
 (87, ((87 - 31) % 30) + 1),
 (88, ((88 - 31) % 30) + 1),
 (89, ((89 - 31) % 30) + 1),
 (90, ((90 - 31) % 30) + 1),
 (91, ((91 - 31) % 30) + 1);

-- Re-enable foreign key checks now that all data has been inserted.
SET FOREIGN_KEY_CHECKS = 1;
