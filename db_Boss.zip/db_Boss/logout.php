<?php
/**
 * Logout script
 *
 * Destroys the current session and redirects back to the home page.  If the
 * session has not been started yet it will be started implicitly.
 */
if (session_status() === PHP_SESSION_NONE)
 { session_start(); }

session_start();
// Destroy the entire session
session_unset();
session_destroy();

// Redirect to the home page
header('Location: login.php');
exit();