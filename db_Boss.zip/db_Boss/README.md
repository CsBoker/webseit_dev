# BOSS RBAC Drop-in
Created: 2025-09-20

This package wires login + role-based access on top of your existing BOSS schema (`db_boss_merged.sql`).
It expects tables: `Account`, `AccountRole`, `AccountType` as seen in your spec.

## Files
- `config.php` — DB connection
- `auth.php` — session helpers and role guards
- `login.php` — login form
- `login_process.php` — authenticates against Account + AccountRole/Type
- `logout.php` — clears session
- `partials/nav.php` — simple role-aware navigation
- `*_dashboard.php` — three dashboards
- `sql/adjust_roles.sql` — optional normalisation of role names

## Setup
1. Import your schema/data (e.g., `db_boss_merged.sql`) into MySQL/MariaDB.
2. (Optional) Run `sql/adjust_roles.sql` to insert canonical roles (`customer|employee|admin`) and map old names.
3. Place these files at your project web root (or merge into your structure).
4. Update `config.php` credentials.
5. Visit `/login.php` and sign in with an email from the `Account` table. For the sample data, passwords are SHA-256 of the plaintext used at insert time (e.g., `password123` for john.doe@example.com).

## Notes
- If you later migrate to `password_hash()`, the code auto-detects and verifies hashed passwords.
- Role resolution prefers `AccountRole.role_name`. If missing, it infers from `AccountType.type_name`. Defaults to `customer`.
