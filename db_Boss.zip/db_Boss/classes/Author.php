<?php
/**
 * Author Model Class
 * Handles author-related database operations
 */

class Author {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    /**
     * Get all authors
     */
    public function getAllAuthors($limit = 50, $offset = 0) {
        $sql = "SELECT a.*, COUNT(ab.id_book) as book_count
                FROM Author a
                LEFT JOIN Author_has_Book ab ON a.id_author = ab.id_author
                GROUP BY a.id_author
                ORDER BY a.last_name, a.first_name
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Get author by ID
     */
    public function getAuthorById($id) {
        $sql = "SELECT * FROM Author WHERE id_author = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }
    
    /**
     * Get author's books
     */
    public function getAuthorBooks($authorId) {
        $sql = "SELECT b.*, c.category_name, p.publisher_name
                FROM Book b
                LEFT JOIN Category c ON b.id_category = c.id_category
                LEFT JOIN Publisher p ON b.id_publisher = p.id_publisher
                LEFT JOIN Author_has_Book ab ON b.id_book = ab.id_book
                WHERE ab.id_author = :author_id
                ORDER BY b.title";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':author_id', $authorId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Add new author
     */
    public function addAuthor($data) {
        $sql = "INSERT INTO Author (first_name, last_name, date_birth, date_death, remark)
                VALUES (:first_name, :last_name, :date_birth, :date_death, :remark)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }
    
    /**
     * Update author
     */
    public function updateAuthor($id, $data) {
        $sql = "UPDATE Author SET first_name = :first_name, last_name = :last_name,
                                 date_birth = :date_birth, date_death = :date_death, remark = :remark
                WHERE id_author = :id";
        
        $data['id'] = $id;
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }
    
    /**
     * Delete author
     */
    public function deleteAuthor($id) {
        $sql = "DELETE FROM Author WHERE id_author = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
    
    /**
     * Get total author count
     */
    public function getTotalAuthors() {
        $sql = "SELECT COUNT(*) as total FROM Author";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['total'];
    }
}
?>
