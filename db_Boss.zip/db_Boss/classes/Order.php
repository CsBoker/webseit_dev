<?php
/**
 * Order Model Class
 * Handles orders and order details
 */

class Order {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Yeni sipariş oluştur
     */
    public function createOrder($userId, $cartItems, $statusId = 1) {
        try {
            $this->db->beginTransaction();

            // Orders tablosuna ekle
            $sql = "INSERT INTO Orders (date_order, id_account, id_order_status) 
                    VALUES (CURDATE(), :user_id, :status_id)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                ':user_id'   => $userId,
                ':status_id' => $statusId
            ]);
            $orderId = $this->db->lastInsertId();

            // OrderDetails tablosuna ekle
            $sqlDetails = "INSERT INTO OrderDetails (id_order, id_book, item_count) 
                           VALUES (:id_order, :id_book, :item_count)";
            $stmtDetails = $this->db->prepare($sqlDetails);

            foreach ($cartItems as $item) {
                $stmtDetails->execute([
                    ':id_order'   => $orderId,
                    ':id_book'    => $item['id_book'],
                    ':item_count' => $item['quantity']
                ]);
            }

            $this->db->commit();
            return $orderId;

        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Kullanıcının tüm siparişlerini getir
     */
    public function getUserOrders($userId) {
        $sql = "SELECT 
                    o.id_order,
                    o.date_order,
                    os.description AS status_description,
                    COALESCE(SUM(od.item_count), 0) AS item_count,
                    COALESCE(SUM(od.item_count * b.price), 0) AS total_amount
                FROM Orders o
                LEFT JOIN OrderStatus os ON o.id_order_status = os.id_order_status
                LEFT JOIN OrderDetails od ON o.id_order = od.id_order
                LEFT JOIN Book b ON od.id_book = b.id_book
                WHERE o.id_account = :user_id
                GROUP BY o.id_order, o.date_order, os.description
                ORDER BY o.date_order DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Tek bir sipariş detaylarını getir
     */
    public function getOrderById($orderId) {
        $sql = "SELECT 
                    o.id_order,
                    o.date_order,
                    os.description AS status_description,
                    a.first_name,
                    a.last_name,
                    a.email,
                    COALESCE(SUM(od.item_count * b.price), 0) AS total_amount
                FROM Orders o
                LEFT JOIN OrderStatus os ON o.id_order_status = os.id_order_status
                LEFT JOIN Account a ON o.id_account = a.id_account
                LEFT JOIN OrderDetails od ON o.id_order = od.id_order
                LEFT JOIN Book b ON od.id_book = b.id_book
                WHERE o.id_order = :id_order
                GROUP BY o.id_order, o.date_order, os.description, a.first_name, a.last_name, a.email";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id_order', $orderId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Sipariş detaylarındaki ürünleri getir
     */
    public function getOrderItems($orderId) {
        $sql = "SELECT 
                    od.id_order_details,
                    od.item_count,
                    b.title,
                    b.price,
                    (od.item_count * b.price) AS subtotal
                FROM OrderDetails od
                LEFT JOIN Book b ON od.id_book = b.id_book
                WHERE od.id_order = :id_order";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id_order', $orderId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>