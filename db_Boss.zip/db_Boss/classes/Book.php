<?php
/**
 * Book Model Class
 * Handles all book-related database operations
 */
class Book {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Get all books with pagination
     */
   public function getAllBooks($limit = 12, $offset = 0, $category = null, $search = null) {
    $sql = "SELECT b.*, c.category_name, p.publisher_name, l.name as language_name,
                   GROUP_CONCAT(CONCAT(a.first_name, ' ', a.last_name) SEPARATOR ', ') as authors
            FROM Book b
            LEFT JOIN Category c ON b.id_category = c.id_category
            LEFT JOIN Publisher p ON b.id_publisher = p.id_publisher
            LEFT JOIN Language l ON b.id_language = l.id_language
            LEFT JOIN Author_has_Book ab ON b.id_book = ab.id_book
            LEFT JOIN Author a ON ab.id_author = a.id_author
            WHERE 1=1";

    $params = [];

    if (!empty($category)) {
        $sql .= " AND c.id_category = ?";
        $params[] = (int)$category;
    }

    if (!empty($search)) {
        $sql .= " AND (b.title LIKE ? OR CONCAT(a.first_name, ' ', a.last_name) LIKE ? OR c.category_name LIKE ?)";
        $searchWildcard = "%$search%";
        $params[] = $searchWildcard;
        $params[] = $searchWildcard;
        $params[] = $searchWildcard;
    }

    // LIMIT ve OFFSET'i direkt göm
    $sql .= " GROUP BY b.id_book ORDER BY b.title LIMIT $limit OFFSET $offset";

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);

    return $stmt->fetchAll();
}
    /**
     * Get total book count
     */
   public function getTotalBooks($category = null, $search = null) {
    $sql = "SELECT COUNT(DISTINCT b.id_book) as total
            FROM Book b
            LEFT JOIN Category c ON b.id_category = c.id_category
            LEFT JOIN Author_has_Book ab ON b.id_book = ab.id_book
            LEFT JOIN Author a ON ab.id_author = a.id_author
            WHERE 1=1";

    $params = [];

    if (!empty($category)) {
        $sql .= " AND c.id_category = ?";
        $params[] = (int)$category;
    }

    if (!empty($search)) {
        $sql .= " AND (b.title LIKE ? 
                   OR CONCAT(a.first_name, ' ', a.last_name) LIKE ? 
                   OR c.category_name LIKE ?)";
        $searchWildcard = "%$search%";
        $params[] = $searchWildcard;
        $params[] = $searchWildcard;
        $params[] = $searchWildcard;
    }

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);

    $result = $stmt->fetch();
    return $result['total'];
}

    /**
     * Get book by ID
     */
    public function getBookById($id) {
        $sql = "SELECT b.*, c.category_name, p.publisher_name, l.name as language_name,
                       GROUP_CONCAT(CONCAT(a.first_name, ' ', a.last_name) SEPARATOR ', ') as authors
                FROM Book b
                LEFT JOIN Category c ON b.id_category = c.id_category
                LEFT JOIN Publisher p ON b.id_publisher = p.id_publisher
                LEFT JOIN Language l ON b.id_language = l.id_language
                LEFT JOIN Author_has_Book ab ON b.id_book = ab.id_book
                LEFT JOIN Author a ON ab.id_author = a.id_author
                WHERE b.id_book = :id
                GROUP BY b.id_book";

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id', (int)$id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * Get featured books
     */
    public function getFeaturedBooks($limit = 8) {
        $sql = "SELECT b.*, c.category_name, p.publisher_name,
                       GROUP_CONCAT(CONCAT(a.first_name, ' ', a.last_name) SEPARATOR ', ') as authors
                FROM Book b
                LEFT JOIN Category c ON b.id_category = c.id_category
                LEFT JOIN Publisher p ON b.id_publisher = p.id_publisher
                LEFT JOIN Author_has_Book ab ON b.id_book = ab.id_book
                LEFT JOIN Author a ON ab.id_author = a.id_author
                WHERE b.is_in_stock = 1
                GROUP BY b.id_book
                ORDER BY RAND()
                LIMIT :limit";

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Add new book
     */
    public function addBook($data) {
        $sql = "INSERT INTO Book (title, isbn, edition, published, info, is_in_stock, price, amount, 
                                 last_changed, id_publisher, id_category, id_language)
                VALUES (:title, :isbn, :edition, :published, :info, :is_in_stock, :price, :amount,
                        NOW(), :id_publisher, :id_category, :id_language)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    /**
     * Update book
     */
    public function updateBook($id, $data) {
        $sql = "UPDATE Book 
                SET title = :title, isbn = :isbn, edition = :edition, 
                    published = :published, info = :info, is_in_stock = :is_in_stock,
                    price = :price, amount = :amount, last_changed = NOW(),
                    id_publisher = :id_publisher, id_category = :id_category,
                    id_language = :id_language
                WHERE id_book = :id";
        
        $data['id'] = (int)$id;
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    /**
     * Delete book
     */
    public function deleteBook($id) {
        $sql = "DELETE FROM Book WHERE id_book = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id', (int)$id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    /**
     * Get full details for a single book, including translations.
     */
    public function getBookDetails($id_book) {
        $sql = "SELECT b.*, c.category_name, p.publisher_name, l.name as language_name,
                       GROUP_CONCAT(CONCAT(lang.id_language, ':', lang.name, ':', bt.translated_title) SEPARATOR '||') as translations,
                       GROUP_CONCAT(DISTINCT CONCAT(a.first_name, ' ', a.last_name) SEPARATOR ', ') as authors
                FROM Book b
                LEFT JOIN Category c ON b.id_category = c.id_category
                LEFT JOIN Publisher p ON b.id_publisher = p.id_publisher
                LEFT JOIN Language l ON b.id_language = l.id_language
                LEFT JOIN Author_has_Book ab ON b.id_book = ab.id_book
                LEFT JOIN Author a ON ab.id_author = a.id_author
                LEFT JOIN BookTranslation bt ON b.id_book = bt.id_book
                LEFT JOIN Language lang ON bt.id_language = lang.id_language
                WHERE b.id_book = :id_book
                GROUP BY b.id_book";

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id_book', (int)$id_book, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }
}
?>