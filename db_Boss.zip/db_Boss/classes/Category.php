<?php
/**
 * Category Model Class
 * Handles category-related database operations
 */

class Category {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    /**
     * Get all categories
     */
    public function getAllCategories() {
        $sql = "SELECT c.*, COUNT(b.id_book) as book_count
                FROM Category c
                LEFT JOIN Book b ON c.id_category = b.id_category
                GROUP BY c.id_category
                ORDER BY c.category_name";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Get category by ID
     */
    public function getCategoryById($id) {
        $sql = "SELECT * FROM Category WHERE id_category = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }
    
    /**
     * Add new category
     */
    public function addCategory($data) {
        $sql = "INSERT INTO Category (category_name, description) VALUES (:category_name, :description)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }
    
    /**
     * Update category
     */
    public function updateCategory($id, $data) {
        $sql = "UPDATE Category SET category_name = :category_name, description = :description WHERE id_category = :id";
        $data['id'] = $id;
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }
    
    /**
     * Delete category
     */
    public function deleteCategory($id) {
        $sql = "DELETE FROM Category WHERE id_category = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
?>
