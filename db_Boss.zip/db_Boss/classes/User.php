<?php
/**
 * User Model Class
 * Handles user authentication and account management
 */

class User {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    /**
     * Register new user
     */
    public function register($data) {
        // Check if email already exists
        if ($this->emailExists($data['email'])) {
            return false;
        }
        
        $sql = "INSERT INTO Account (account_name, date_created, first_name, last_name, 
                                   date_birth, email, password_hash, phone, remark, id_type, id_role)
                VALUES (:account_name, CURDATE(), :first_name, :last_name, :date_birth, 
                        :email, :password_hash, :phone, :remark, 1, 2)";
        
        $stmt = $this->db->prepare($sql);
        
        $params = [
            'account_name' => $data['account_name'],
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'date_birth' => $data['date_birth'] ?? null,
            'email' => $data['email'],
            'password_hash' => password_hash($data['password'], PASSWORD_DEFAULT),
            'phone' => $data['phone'] ?? null,
            'remark' => 'Regular customer'
        ];
        
        return $stmt->execute($params);
    }
    
    /**
     * Login user with support for legacy SHA-256 hex hashes.
     * On successful legacy login, the password is upgraded to password_hash().
     */
    public function login($email, $password) {
        $sql = "SELECT a.*, at.type_name, ar.role_name 
                FROM Account a
                LEFT JOIN AccountType at ON a.id_type = at.id_type
                LEFT JOIN AccountRole ar ON a.id_role = ar.id_role
                WHERE a.email = :email";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        $user = $stmt->fetch();
        if (!$user) {
            return false;
        }

        $stored = $user['password_hash'] ?? '';
        $ok = false;

        // Try modern PHP hash first
        if ($stored && password_get_info($stored)['algo'] !== 0) {
            if (password_verify($password, $stored)) {
                $ok = true;
                // Rehash if needed (algorithm/params changed)
                if (password_needs_rehash($stored, PASSWORD_DEFAULT)) {
                    $newHash = password_hash($password, PASSWORD_DEFAULT);
                    $upd = $this->db->prepare("UPDATE Account SET password_hash = :h WHERE id_account = :id");
                    $upd->execute([':h' => $newHash, ':id' => $user['id_account']]);
                }
            }
        }

        // Fallback: legacy SHA-256 hex from seed SQL
        if (!$ok && $stored) {
            $sha = hash('sha256', $password); // lowercase hex string
            if (hash_equals(strtolower($stored), strtolower($sha))) {
                $ok = true;
                // Upgrade to modern hash
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $upd = $this->db->prepare("UPDATE Account SET password_hash = :h WHERE id_account = :id");
                $upd->execute([':h' => $newHash, ':id' => $user['id_account']]);
                $stored = $newHash;
            }
        }

        if (!$ok) {
            return false;
        }
        
        // Set session variables (consistent with rest of app)
        $_SESSION['user_id']    = $user['id_account'];
        $_SESSION['user_name']  = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_type']  = $user['type_name'];
        // Normalize the role name to lowercase and fallback to type if needed
        $normalizedRole = strtolower($user['role_name'] ?? '');
        if ($normalizedRole === '') {
            // If no explicit role, use the account type (employee/admin/customer)
            $normalizedRole = strtolower($user['type_name'] ?? 'customer');
        }
        $_SESSION['user_role'] = $normalizedRole;
        // Populate the canonical role key used by auth.php/nav.php
        $_SESSION['role'] = $normalizedRole;
        
        return $user;
    }
    
    /**
     * Get user by ID
     */
    public function getUserById($id) {
        $sql = "SELECT a.*, at.type_name, ar.role_name 
                FROM Account a
                LEFT JOIN AccountType at ON a.id_type = at.id_type
                LEFT JOIN AccountRole ar ON a.id_role = ar.id_role
                WHERE a.id_account = :id";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }
    
    /**
     * Update user profile
     */
    public function updateProfile($id, $data) {
        $sql = "UPDATE Account SET first_name = :first_name, last_name = :last_name,
                                  date_birth = :date_birth, phone = :phone
                WHERE id_account = :id";
        
        $data['id'] = $id;
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }
    
    /**
     * Change password
     */
    public function changePassword($id, $newPassword) {
        $sql = "UPDATE Account SET password_hash = :password_hash WHERE id_account = :id";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':password_hash', password_hash($newPassword, PASSWORD_DEFAULT));
        return $stmt->execute();
    }
    
    /**
     * Check if email exists
     */
    private function emailExists($email) {
        $sql = "SELECT id_account FROM Account WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch() !== false;
    }
    
    /**
     * Logout user
     */
    public function logout() {
        session_destroy();
        return true;
    }
}
?>
