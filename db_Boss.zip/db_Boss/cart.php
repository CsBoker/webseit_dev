<?php 
require_once 'config/config.php';

$bookModel = new Book();

// Sepet session’dan al
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$cart = $_SESSION['cart'] ?? [];
$cartBooks = [];
$total = 0;

if (!empty($cart)) {
    foreach ($cart as $id_book => $qty) {
        $book = $bookModel->getBookById($id_book);
        if ($book) {
            $book['qty'] = $qty;
            $book['subtotal'] = $book['price'] * $qty;
            $total += $book['subtotal'];
            $cartBooks[] = $book;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        table { width:100%; border-collapse:collapse; margin-top:20px; }
        th, td { border:1px solid #ddd; padding:10px; text-align:left; }
        th { background:#f4f4f4; }
        .total { font-weight:bold; font-size:18px; text-align:right; padding:15px; }
        .btn { padding:8px 12px; background:#2563eb; color:#fff; border:none; border-radius:6px; cursor:pointer; text-decoration:none; }
        .btn-danger { background:#dc2626; }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <h1><i class="fas fa-shopping-cart"></i> Shopping Cart</h1>

            <?php if (empty($cartBooks)): ?>
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <h3>Your cart is empty</h3>
                    <p>Browse our collection and add some books to your cart.</p>
                    <a href="books.php" class="btn">Browse Books</a>
                </div>
            <?php else: ?>
                <table>
                    <tr>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Actions</th>
                    </tr>
                    <?php foreach ($cartBooks as $book): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($book['title']); ?></td>
                        <td>$<?php echo number_format($book['price'], 2); ?></td>
                        <td><?php echo $book['qty']; ?></td>
                        <td>$<?php echo number_format($book['subtotal'], 2); ?></td>
                        <td>
                            <a class="btn btn-danger" href="remove_from_cart.php?id=<?php echo $book['id_book']; ?>">Remove</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <div class="total">
                    Total: $<?php echo number_format($total, 2); ?>
                </div>
                <a href="checkout.php" class="btn">Proceed to Checkout</a>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>