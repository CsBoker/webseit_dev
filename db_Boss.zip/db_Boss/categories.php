<?php 
require_once 'config/config.php';

$categoryModel = new Category();
$categories = $categoryModel->getAllCategories();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1>Browse by Category</h1>
                <p>Discover books organized by genre and topic</p>
            </div>

            <div class="categories-page-grid">
                <?php 
                $categoryIcons = [
                    'Fiction' => 'fas fa-book-open',
                    'Non-fiction' => 'fas fa-newspaper',
                    'Science' => 'fas fa-flask',
                    'Fantasy' => 'fas fa-dragon',
                    'History' => 'fas fa-landmark',
                    'Biography' => 'fas fa-user',
                    'Children' => 'fas fa-child',
                    'Mystery' => 'fas fa-search',
                    'Romance' => 'fas fa-heart',
                    'Horror' => 'fas fa-ghost',
                    'Self-help' => 'fas fa-lightbulb',
                    'Philosophy' => 'fas fa-brain',
                    'Psychology' => 'fas fa-head-side-virus',
                    'Religion' => 'fas fa-pray',
                    'Education' => 'fas fa-graduation-cap',
                    'Health' => 'fas fa-heartbeat',
                    'Politics' => 'fas fa-balance-scale',
                    'Art' => 'fas fa-palette',
                    'Travel' => 'fas fa-plane',
                    'Comics' => 'fas fa-mask',
                    'Poetry' => 'fas fa-feather-alt',
                    'Drama' => 'fas fa-theater-masks',
                    'Economics' => 'fas fa-chart-line',
                    'Law' => 'fas fa-gavel',
                    'Technology' => 'fas fa-laptop-code'
                ];
                
                foreach ($categories as $category): 
                    $iconClass = $categoryIcons[$category['category_name']] ?? 'fas fa-book';
                ?>
                    <a href="books.php?category=<?php echo $category['id_category']; ?>" class="category-page-card">
                        <div class="category-icon">
                            <i class="<?php echo $iconClass; ?>"></i>
                        </div>
                        <div class="category-info">
                            <h3><?php echo htmlspecialchars($category['category_name']); ?></h3>
                            <p><?php echo htmlspecialchars($category['description']); ?></p>
                            <span class="book-count"><?php echo $category['book_count']; ?> books</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>
