<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (isset($_SESSION['user_id'])) {
    // Already logged in; send to their dashboard
    $role = strtolower($_SESSION['role'] ?? 'customer');
    if ($role === 'admin') header('Location: /admin_dashboard.php');
    elseif ($role === 'employee') header('Location: /employee_dashboard.php');
    else header('Location: /customer_dashboard.php');
    exit;
}
$err = $_GET['e'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>BOSS Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 0; background:#f6f7fb; }
    .wrap { max-width: 420px; margin: 8vh auto; background:#fff; padding:24px 28px; border-radius:16px; box-shadow:0 8px 24px rgba(0,0,0,.08); }
    h1 { margin: 0 0 12px; font-size: 22px; }
    .field { margin: 12px 0; }
    label { display:block; font-size: 14px; margin-bottom: 6px; }
    input[type="text"], input[type="password"] { width: 100%; padding: 10px 12px; border:1px solid #d7dbe7; border-radius:10px; font-size: 15px; }
    button { margin-top: 12px; width: 100%; padding: 10px 14px; border: 0; border-radius: 10px; background: #2f6fed; color: #fff; font-weight:600; cursor: pointer; }
    .err { background:#fee; color:#900; padding:10px 12px; border-radius:10px; border:1px solid #f5c2c7; margin:10px 0; font-size:14px; }
    .hint { font-size: 12px; color:#666; margin-top:8px; }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Login</h1>
    <?php if ($err): ?>
      <div class="err">
        <?php
          if ($err === 'invalid') echo "Invalid email or password.";
          elseif ($err === 'not_logged_in') echo "Please login to continue.";
          else echo "There was a problem. Please try again.";
        ?>
      </div>
    <?php endif; ?>
    <form method="post" action="/login_process.php" autocomplete="off">
      <div class="field">
        <label for="email">Email</label>
        <input type="text" id="email" name="email" required />
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required />
      </div>
      <button type="submit">Sign in</button>
      <p class="hint">Use an email that exists in the <code>Account</code> table.</p>
    </form>
  </div>
</body>
</html>
