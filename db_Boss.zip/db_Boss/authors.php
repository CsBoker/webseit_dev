<?php 
require_once 'config/config.php';

$authorModel = new Author();

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$authors = $authorModel->getAllAuthors($limit, $offset);
$totalAuthors = $authorModel->getTotalAuthors();
$totalPages = ceil($totalAuthors / $limit);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authors - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1>Authors</h1>
                <p>Discover books by your favorite authors</p>
            </div>

            <div class="authors-grid">
                <?php foreach ($authors as $author): ?>
                    <div class="author-card">
                        <div class="author-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="author-info">
                            <h3 class="author-name">
                                <?php echo htmlspecialchars(trim($author['first_name'] . ' ' . $author['last_name'])); ?>
                            </h3>
                            
                            <?php if ($author['date_birth'] || $author['date_death']): ?>
                                <p class="author-dates">
                                    <?php 
                                    if ($author['date_birth']) {
                                        echo date('Y', strtotime($author['date_birth']));
                                    }
                                    if ($author['date_death']) {
                                        echo ' - ' . date('Y', strtotime($author['date_death']));
                                    } elseif ($author['date_birth']) {
                                        echo ' - Present';
                                    }
                                    ?>
                                </p>
                            <?php endif; ?>
                            
                            <p class="book-count">
                                <i class="fas fa-book"></i>
                                <?php echo $author['book_count']; ?> book<?php echo $author['book_count'] != 1 ? 's' : ''; ?>
                            </p>
                            
                            <?php if ($author['remark']): ?>
                                <p class="author-description">
                                    <?php echo htmlspecialchars($author['remark']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <a href="author-books.php?id=<?php echo $author['id_author']; ?>" class="btn btn-primary">
                                View Books
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>" class="btn">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <a href="?page=<?php echo $i; ?>" class="btn <?php echo $i == $page ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>" class="btn">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>
