<?php
/**
 * User profile page
 *
 * Allows logged‑in users to view and update their personal information
 * as well as change their password.  Guests are redirected to the
 * login page.  All inputs are sanitized before being passed to the
 * model layer.
 */

require_once 'config/config.php';

// Ensure user is authenticated
if (!isLoggedIn()) {
    $redirectUrl = urlencode('profile.php');
    header("Location: login.php?redirect=$redirectUrl");
    exit();
}

$userModel = new User();
$userId = $_SESSION['user_id'];
$user = $userModel->getUserById($userId);

$profileError = '';
$profileSuccess = '';
$passwordError = '';
$passwordSuccess = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $data = [
        'first_name' => sanitize($_POST['first_name'] ?? ''),
        'last_name' => sanitize($_POST['last_name'] ?? ''),
        'date_birth' => $_POST['date_birth'] ?: null,
        'phone' => sanitize($_POST['phone'] ?? '')
    ];
    if (empty($data['first_name']) || empty($data['last_name'])) {
        $profileError = 'Please provide both first and last names.';
    } else {
        if ($userModel->updateProfile($userId, $data)) {
            $profileSuccess = 'Profile updated successfully.';
            // Refresh user details
            $user = $userModel->getUserById($userId);
        } else {
            $profileError = 'Could not update profile. Please try again.';
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    if (strlen($newPassword) < 6) {
        $passwordError = 'New password must be at least 6 characters.';
    } elseif ($newPassword !== $confirmPassword) {
        $passwordError = 'Passwords do not match.';
    } else {
        if ($userModel->changePassword($userId, $newPassword)) {
            $passwordSuccess = 'Password changed successfully.';
        } else {
            $passwordError = 'Could not change password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1>My Profile</h1>
                <p>Update your personal information and password</p>
            </div>

            <div class="profile-container">
                <div class="profile-card">
                    <h2><i class="fas fa-user"></i> Personal Information</h2>
                    <?php if ($profileError): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $profileError; ?>
                        </div>
                    <?php elseif ($profileSuccess): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <?php echo $profileSuccess; ?>
                        </div>
                    <?php endif; ?>
                    <form method="POST">
                        <input type="hidden" name="action" value="update_profile">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">First Name *</label>
                                <input type="text" id="first_name" name="first_name" required
                                       value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" required
                                       value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="date_birth">Date of Birth</label>
                                <input type="date" id="date_birth" name="date_birth"
                                       value="<?php echo $user['date_birth'] ? htmlspecialchars($user['date_birth']) : ''; ?>">
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="tel" id="phone" name="phone"
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-full">Save Changes</button>
                    </form>
                </div>
                <div class="profile-card">
                    <h2><i class="fas fa-lock"></i> Change Password</h2>
                    <?php if ($passwordError): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $passwordError; ?>
                        </div>
                    <?php elseif ($passwordSuccess): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <?php echo $passwordSuccess; ?>
                        </div>
                    <?php endif; ?>
                    <form method="POST">
                        <input type="hidden" name="action" value="change_password">
                        <div class="form-group">
                            <label for="new_password">New Password *</label>
                            <input type="password" id="new_password" name="new_password" required>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password *</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-full">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>