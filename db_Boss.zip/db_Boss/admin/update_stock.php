<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

$role = strtolower($_SESSION['role'] ?? $_SESSION['user_role'] ?? '');
if ($role !== 'employee' && $role !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$bookModel = new Book();
$id = (int)($_GET['id'] ?? 0);
$book = $bookModel->getBookById($id);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (int)$_POST['amount'];
    $price  = (float)$_POST['price'];
    $bookModel->updateStock($id, $amount, $price);
    header("Location: employee_dashboard.php?success=1");
    exit();
}
?>

<h1>Update Stock</h1>
<form method="post">
    <label>Amount:</label>
    <input type="number" name="amount" value="<?php echo $book['amount']; ?>" required>
    <label>Price:</label>
    <input type="text" name="price" value="<?php echo $book['price']; ?>" required>
    <button type="submit">Save</button>
</form>