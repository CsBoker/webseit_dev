<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = DatabaseConfig::getInstance()->getConnection();
    $stmt = $db->prepare("INSERT INTO Book (title, isbn, price, amount, id_category, id_publisher, id_language, is_in_stock, published, edition, info, last_changed) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW(), 1, '', NOW())");
    $stmt->execute([$_POST['title'], $_POST['isbn'], $_POST['price'], $_POST['amount'], $_POST['id_category'], $_POST['id_publisher'], $_POST['id_language']]);
    header("Location: admin_dashboard.php");
    exit();
}
?>

<form method="post">
  <label>Title: <input type="text" name="title" required></label><br>
  <label>ISBN: <input type="text" name="isbn" required></label><br>
  <label>Price: <input type="number" step="0.01" name="price" required></label><br>
  <label>Amount: <input type="number" name="amount" required></label><br>
  <label>Category ID: <input type="number" name="id_category"></label><br>
  <label>Publisher ID: <input type="number" name="id_publisher"></label><br>
  <label>Language ID: <input type="number" name="id_language" value="44"></label><br>
  <button type="submit">Save</button>
</form>
