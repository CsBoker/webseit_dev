<?php
// admin/reply_message.php — inserts an EMPLOYEE reply under the customer's question
// Fix for: ambiguous column error in ON DUPLICATE KEY UPDATE.
// Strategy: use INSERT IGNORE ... SELECT (no ON DUPLICATE), so duplicates are skipped.

require_once __DIR__ . '/../auth.php';
require_login();
if (function_exists('require_role')) {
    require_role(['employee', 'admin']);
}

require_once __DIR__ . '/../config/config.php'; // exposes getDB() returning PDO

$pdo = getDB();
if (!$pdo) {
    http_response_code(500);
    die('Database connection not available!');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// Read form inputs
$replyText  = trim($_POST['reply_text'] ?? '');
$replyTo    = (int)($_POST['reply_to'] ?? $_POST['id_message'] ?? $_POST['message_id'] ?? 0);
$employeeId = (int)($_SESSION['user_id'] ?? 0);

if ($employeeId <= 0) {
    header('Location: /login.php?e=not_logged_in');
    exit;
}

if ($replyText === '') {
    header('Location: employee_dashboard.php?e=empty_reply');
    exit;
}

// Optional: ensure the session belongs to an Employee/Admin (for attribution/labeling)
$checkRole = $pdo->prepare("
    SELECT at.type_name, ar.role_name
    FROM Account a
    LEFT JOIN AccountType at ON at.id_type = a.id_type
    LEFT JOIN AccountRole ar ON ar.id_role = a.id_role
    WHERE a.id_account = :id
");
$checkRole->execute([':id' => $employeeId]);
$roleRow = $checkRole->fetch(PDO::FETCH_ASSOC);
if (!$roleRow) {
    http_response_code(403);
    die('Unknown user for reply');
}

try {
    $pdo->beginTransaction();

    // 1) Verify parent exists (lock it during write)
    $parentExists = false;
    if ($replyTo > 0) {
        $check = $pdo->prepare('SELECT id_message FROM Message WHERE id_message = :id FOR UPDATE');
        $check->execute([':id' => $replyTo]);
        $parentExists = (bool)$check->fetchColumn();
        if (!$parentExists) {
            $replyTo = 0; // fallback to standalone message
        }
    }

    // 2) Insert employee's reply
    $stmt = $pdo->prepare(
        'INSERT INTO Message (timestamp_message, message_content, id_account)
         VALUES (NOW(), :content, :id_account)'
    );
    $stmt->execute([
        ':content'    => $replyText,
        ':id_account' => $employeeId,
    ]);
    $newMessageId = (int)$pdo->lastInsertId();

    // 3) Closure: self link for new message
    $pdo->prepare('
        INSERT IGNORE INTO MessageClosure (ancestor, descendant) VALUES (:m1, :m2)
    ')->execute([':m1' => $newMessageId, ':m2' => $newMessageId]);

    if ($replyTo > 0 && $parentExists) {
        // direct parent -> child link
        $pdo->prepare('
            INSERT IGNORE INTO MessageClosure (ancestor, descendant) VALUES (:p, :c)
        ')->execute([':p' => $replyTo, ':c' => $newMessageId]);

        // transitive links: all ancestors of parent -> child
        $pdo->prepare('
            INSERT IGNORE INTO MessageClosure (ancestor, descendant)
            SELECT mc.ancestor, :child
            FROM MessageClosure AS mc
            WHERE mc.descendant = :parent
        ')->execute([':child' => $newMessageId, ':parent' => $replyTo]);
    }

    $pdo->commit();

    // Redirect back to the thread view. Use ASC order by timestamp to show replies below the question.
    $target = 'employee_dashboard.php';
    if ($replyTo > 0 && $parentExists) {
        $target .= '?thread=' . $replyTo . '#m' . $newMessageId;
    } else {
        $target .= '#m' . $newMessageId;
    }
    header('Location: ' . $target);
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    die('Failed to save reply (no changes were made): ' . htmlspecialchars($e->getMessage()));
}
