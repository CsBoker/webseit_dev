<?php
/**
 * Logout script
 *
 * Destroys the current session and redirects back to the home page.  If the
 * session has not been started yet it will be started implicitly.
 */

require_once __DIR__ .'/../config/config.php';


session_start();
// Destroy the entire session
session_unset();
session_destroy();

// Redirect to the home page
header('Location: ../index.php');
exit();