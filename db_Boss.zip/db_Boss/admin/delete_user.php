<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth.php';
require_role(['admin']);

$id = $_GET['id'];

$stmt = $pdo->prepare("DELETE FROM account WHERE id_account = ?");
$stmt->execute([$id]);

header("Location: manage_users.php");
exit;
?>