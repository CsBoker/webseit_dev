<?php
require __DIR__ . '/../auth.php';
require_login();
require_role(['admin']);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

$pdo = getDB();
if (!$pdo) {
    die("Database connection not available!");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../assets/css/style.css"> <!-- kendi ana CSS'in -->
  <style>
    body { font-family: Arial, sans-serif; background:#f9fafb; margin:0; }
    .page { max-width: 1200px; margin: 30px auto; padding: 0 20px; }
    .card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 4px 12px rgba(0,0,0,.08); margin-bottom:30px; }
    h1 { font-size: 24px; margin-bottom:10px; }
    .muted { color:#6b7280; margin-bottom:15px; }

    .links { display:flex; gap:15px; margin-bottom:20px; }
    .links a {
      background:#2563eb; color:#fff; padding:8px 14px;
      border-radius:6px; text-decoration:none; font-size:14px;
    }
    .links a:hover { background:#1d4ed8; }

    table { width:100%; border-collapse: collapse; }
    th, td { padding: 10px 12px; border: 1px solid #e5e7eb; }
    th { background:#f3f4f6; text-align:left; font-weight:bold; }
    tr:nth-child(even) { background:#f9fafb; }
    td:nth-child(1), td:nth-child(3), td:nth-child(5) { text-align:center; }
    td:nth-child(4) { text-align:right; }
    .actions a { margin-right:10px; color:#2563eb; text-decoration:none; }
    .actions a:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <?php include __DIR__ . '/../includes/header.php'; ?>
  
  <div class="page">
    <div class="card">
      <h1>Admin Dashboard</h1>
      <p class="muted">Full control over books, orders, users, types/roles.</p>
      <div class="links">
        <a href="manage_users.php">👥 Manage Users</a>
        <a href="book_create.php">➕ Add New Book</a>
        <a href="#">📊 View Reports</a>
      </div>
    </div>

    <div class="card">
      <h1>Manage Books</h1>
      <?php
      $sql = "SELECT b.id_book, b.title, b.isbn, b.price, b.amount, c.category_name, p.publisher_name 
              FROM Book b
              LEFT JOIN Category c ON b.id_category = c.id_category
              LEFT JOIN Publisher p ON b.id_publisher = p.id_publisher
              ORDER BY b.id_book ASC";
      $stmt = $pdo->query($sql);
      ?>
      <table>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>ISBN</th>
          <th>Price (€)</th>
          <th>Amount</th>
          <th>Category</th>
          <th>Publisher</th>
          <th>Actions</th>
        </tr>
        <?php while ($row = $stmt->fetch()): ?>
        <tr>
          <td><?= $row['id_book'] ?></td>
          <td><?= htmlspecialchars($row['title']) ?></td>
          <td><?= $row['isbn'] ?></td>
          <td><?= number_format($row['price'], 2) ?></td>
          <td><?= $row['amount'] ?></td>
          <td><?= $row['category_name'] ?></td>
          <td><?= $row['publisher_name'] ?></td>
          <td class="actions">
            <a href="book_edit.php?id=<?= $row['id_book'] ?>">✏ Edit</a>
            <a href="book_delete.php?id=<?= $row['id_book'] ?>" onclick="return confirm('Are you sure?')">🗑 Delete</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </table>
    </div>
  </div>
</body>
</html>