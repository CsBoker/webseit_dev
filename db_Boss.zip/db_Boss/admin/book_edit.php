<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role(['admin']);

$db = DatabaseConfig::getInstance()->getConnection();
$id = intval($_GET['id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $db->prepare("UPDATE Book SET title=?, isbn=?, price=?, amount=? WHERE id_book=?");
    $stmt->execute([$_POST['title'], $_POST['isbn'], $_POST['price'], $_POST['amount'], $id]);
    header("Location: admin_dashboard.php");
    exit();
}

$stmt = $db->prepare("SELECT * FROM Book WHERE id_book=?");
$stmt->execute([$id]);
$book = $stmt->fetch();
?>

<form method="post">
  <label>Title: <input type="text" name="title" value="<?= htmlspecialchars($book['title']) ?>"></label><br>
  <label>ISBN: <input type="text" name="isbn" value="<?= $book['isbn'] ?>"></label><br>
  <label>Price: <input type="number" step="0.01" name="price" value="<?= $book['price'] ?>"></label><br>
  <label>Amount: <input type="number" name="amount" value="<?= $book['amount'] ?>"></label><br>
  <button type="submit">Update</button>
</form>
