<?php
/**
 * Admin dashboard placeholder
 *
 * This page is displayed when an administrator clicks the "Admin"
 * navigation link.  At present it simply informs the user that
 * administrative functionality has not yet been implemented.  Access
 * control is enforced by the isAdmin() helper function defined in
 * config/config.php.
 */

require_once '../config/config.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1>Admin Dashboard</h1>
                <p>Administrative tools are under construction.</p>
            </div>
            <p>Check back later for features such as managing books,
                categories, authors, orders and users.</p>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
    <script src="../assets/js/main.js"></script>
</body>
</html>