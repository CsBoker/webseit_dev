<?php
require __DIR__ . '/../auth.php';
require_login();
require_role(['employee', 'admin']);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: employee_dashboard.php');
    exit();
}

$id = isset($_POST['id_order']) ? (int)$_POST['id_order'] : 0;
if ($id <= 0) {
    header('Location: employee_dashboard.php?error=invalid_id');
    exit();
}

$pdo = getDB();
if (!$pdo) {
    die("Database connection not available!");
}

try {
    $pdo->beginTransaction();

    // Optional: check the order exists
    $stmt = $pdo->prepare("SELECT id_order FROM Orders WHERE id_order = ? FOR UPDATE");
    $stmt->execute([$id]);
    $exists = $stmt->fetchColumn();

    if (!$exists) {
        $pdo->rollBack();
        header('Location: employee_dashboard.php?error=not_found');
        exit();
    }

    // Delete the order; OrderDetails has ON DELETE CASCADE (per schema)
    $del = $pdo->prepare("DELETE FROM Orders WHERE id_order = ?");
    $del->execute([$id]);

    $pdo->commit();
    header('Location: employee_dashboard.php?deleted=1');
    exit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    die("Delete failed: " . htmlspecialchars($e->getMessage()));
}
