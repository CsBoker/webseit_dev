<?php
require __DIR__ . '/../auth.php';
require_login();
require_role(['employee', 'admin']); 

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

$pdo = getDB();
if (!$pdo) {
    die("Database connection not available!");
}

// Sipariş ID’sini al
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// Sipariş detaylarını çek
$stmt = $pdo->prepare("SELECT * FROM Orders WHERE id_order = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();

if (!$order) {
    die("Order not found!");
}

// Status seçeneklerini çek
$statusStmt = $pdo->query("SELECT id_order_status, description FROM OrderStatus");
$statuses = $statusStmt->fetchAll();

// Form gönderildiyse güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus = (int) $_POST['status'];

    $updateStmt = $pdo->prepare("UPDATE Orders SET id_order_status = ? WHERE id_order = ?");
    $updateStmt->execute([$newStatus, $id]);

    header("Location: employee_dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Update Order</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    body { font-family: Arial, sans-serif; background:#f8fafc; margin:0; padding:20px; }
    .card { background:#fff; border-radius:10px; padding:20px; box-shadow:0 2px 10px rgba(0,0,0,.1); max-width:500px; margin:auto; }
    select, button { width:100%; padding:10px; margin-top:10px; }
    button { background:#2563eb; color:#fff; border:none; border-radius:6px; cursor:pointer; }
  </style>
</head>
<body>
  <div class="card">
    <h2>Update Order #<?= htmlspecialchars($order['id_order']) ?></h2>
    <form method="post">
      <label for="status">Status</label>
      <select name="status" id="status">
        <?php foreach ($statuses as $st): ?>
          <option value="<?= $st['id_order_status'] ?>" 
            <?= $st['id_order_status'] == $order['id_order_status'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($st['description']) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <button type="submit">Save</button>
    </form>
  </div>
</body>
</html>