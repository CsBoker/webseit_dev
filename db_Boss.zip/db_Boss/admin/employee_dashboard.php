<?php
require __DIR__ . '/../auth.php';
require_login();
require_role(['employee', 'admin']); 

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

// PDO bağlantısı
$pdo = getDB();
if (!$pdo) {
    die("Database connection not available!");
}

// Siparişleri çek
try {
    $sql = "SELECT 
                o.id_order, 
                o.date_order, 
                os.description AS status, 
                CONCAT(a.first_name, ' ', a.last_name) AS customer, 
                COALESCE(CONCAT(addr.address1, ', ', addr.zip, ' ', addr.city), o.shipping_address, '') AS address
            FROM Orders o
            LEFT JOIN Account a ON o.id_account = a.id_account
            LEFT JOIN OrderStatus os ON o.id_order_status = os.id_order_status
            LEFT JOIN Address addr ON addr.id_address = o.id_address
            ORDER BY o.id_order DESC";
    $orders = $pdo->query($sql)->fetchAll();
} catch (PDOException $e) {
    die("Orders failed: " . htmlspecialchars($e->getMessage()));
}

//} catch (PDOException $e) {
//   die("Orders failed: " . htmlspecialchars($e->getMessage()));


// Mesajları çek
try {
    $sqlMsg = "SELECT 
                   m.id_message, 
                   m.message_content, 
                   m.timestamp_message,
                   CONCAT(a.first_name, ' ', a.last_name) AS user
               FROM Message m
               LEFT JOIN Account a ON m.id_account = a.id_account
               ORDER BY m.timestamp_message DESC";
    $messages = $pdo->query($sqlMsg)->fetchAll();
} catch (PDOException $e) {
    die("Messages failed: " . htmlspecialchars($e->getMessage()));
}

// Kitap / stokları çek
try {
    $sqlStock = "SELECT id_book, title, amount, price 
                 FROM Book 
                 ORDER BY id_book ASC 
                 LIMIT 50";
    $books = $pdo->query($sqlStock)->fetchAll();
} catch (PDOException $e) {
    $books = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Employee Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    body { font-family: Arial, sans-serif; background:#f8fafc; margin:0; }
    .page { max-width: 1100px; margin: 24px auto; padding: 0 16px; }
    .card { background:#fff; border-radius:16px; padding:20px; box-shadow:0 4px 16px rgba(0,0,0,.06); margin-bottom:20px; }
    h1 { font-size: 22px; margin-bottom: 12px; }
    .muted { color:#64748b; font-size:14px; }
    table { width:100%; border-collapse: collapse; margin-top:16px; }
    th, td { padding: 10px; border: 1px solid #ddd; text-align:left; }
    th { background:#f1f5f9; }
    .action-btn { margin-right: 6px; color:#2563eb; text-decoration:none; }
    .message { padding:10px; border-bottom:1px solid #ddd; }
    form textarea { width:100%; height:60px; margin-top:8px; }
    form button { margin-top:6px; padding:6px 12px; background:#2563eb; color:#fff; border:none; border-radius:6px; cursor:pointer; }
  </style>
</head>
<body>
  <?php include __DIR__ . '/../includes/header.php'; ?>

  <div class="page">
    <div class="card">
      <h1>Employee Dashboard</h1>
      <p class="muted">Here you can manage orders, reply to customer messages and update stock.</p>
    </div>

    <!-- Orders -->
    <div class="card">
      <h1>Manage Orders</h1>
      <table>
        <tr>
          <th>ID</th>
          <th>Customer</th>
          <th>Address</th>
          <th>Date</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
        <?php foreach ($orders as $order): ?>
        <tr>
          <td><?= $order['id_order'] ?></td>
          <td><?= htmlspecialchars($order['customer'] ?? '') ?></td>
          <td><?= htmlspecialchars($order['address'] ?? '') ?></td>
          <td><?= $order['date_order'] ?></td>
          <td><?= htmlspecialchars($order['status'] ?? '') ?></td>
          <td>
            <a class="action-btn" href="order_update.php?id=<?= $order['id_order'] ?>">✏ Update</a>
            <form method="post" action="order_delete.php" style="display:inline" onsubmit="return confirm('Delete this order? This cannot be undone.');">
              <input type="hidden" name="id_order" value="<?= (int)$order['id_order'] ?>">
              <button type="submit" class="action-btn" style="background:#b00020;border-color:#a0001a;">🗑 Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>

    <!-- Messages -->
    <div class="card">
      <h1>Customer Messages</h1>
      <?php foreach ($messages as $msg): ?>
        <div class="message">
          <strong><?= htmlspecialchars($msg['user']) ?>:</strong> 
          <?= htmlspecialchars($msg['message_content']) ?>
          <div class="muted"><?= $msg['timestamp_message'] ?></div>

          <form method="post" action="reply_message.php">
            <input type="hidden" name="reply_to" value="<?= $msg['id_message'] ?>">
            <textarea name="reply_text" placeholder="write a reply"></textarea>
            <button type="submit">Answer</button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Stock Management -->
    <div class="card">
      <h1>Manage Stock</h1>
      <table>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Amount</th>
          <th>Price (€)</th>
          <th>Actions</th>
        </tr>
        <?php foreach ($books as $book): ?>
        <tr>
          <td><?= $book['id_book'] ?></td>
          <td><?= htmlspecialchars($book['title']) ?></td>
          <td><?= $book['amount'] ?></td>
          <td><?= number_format($book['price'], 2) ?></td>
          <td>
            <a class="action-btn" href="update_stock.php?id=<?= $book['id_book'] ?>">✏ Update</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
  </div>
</body>
</html>