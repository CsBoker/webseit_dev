<?php
// customer_dashboard.php

require_once __DIR__ . '/../config/config.php'; // config dosyanı doğru çağırıyoruz
require_once __DIR__ . '/../auth.php';

// sadece müşteri ve admin girebilsin
require_login();
require_role(['customer', 'admin']);

// PDO bağlantısını al
$pdo = getDB();
if (!$pdo) {
    die("Database connection not available!");
}

// Kitapları çek
try {
    $stmt = $pdo->query("SELECT id_book, title, price, amount FROM Book ORDER BY title ASC");
    $books = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Query failed: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Customer Dashboard</title>
  <style>
    body { font-family: Arial, sans-serif; background:#f8fafc; margin:0; padding:20px; }
    .page { max-width: 900px; margin: 0 auto; }
    .card { background:#fff; border-radius:12px; padding:20px; margin-bottom:20px; box-shadow:0 4px 8px rgba(0,0,0,0.05); }
    h1 { font-size:22px; margin-bottom:12px; }
    table { width:100%; border-collapse: collapse; margin-top:12px; }
    th, td { border:1px solid #ddd; padding:8px; text-align:left; }
    th { background:#f1f5f9; }
  </style>
</head>
<body>
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="page">
    <div class="card">
      <h1>Customer Dashboard</h1>
      <p>Customer area: browse and place orders, view order history.</p>
      <ul>
        <li>Search & order books</li>
        <li>View/cancel pending orders</li>
        <li>Message support</li>
      </ul>
    </div>

    <div class="card">
      <h1>Available Books</h1>
      <?php if ($books): ?>
      <table>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Price</th>
          <th>Stock</th>
        </tr>
        <?php foreach ($books as $book): ?>
        <tr>
          <td><?= htmlspecialchars($book['id_book']) ?></td>
          <td><?= htmlspecialchars($book['title']) ?></td>
          <td><?= htmlspecialchars($book['price']) ?> €</td>
          <td><?= htmlspecialchars($book['amount']) ?></td>
        </tr>
        <?php endforeach; ?>
      </table>
      <?php else: ?>
        <p>No books available.</p>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>