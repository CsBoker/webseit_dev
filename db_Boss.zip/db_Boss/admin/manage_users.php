<?php
require_once __DIR__ . '/../config/config.php';

try {
    // Kullanıcıları ve rollerini çek
    $sql = "SELECT a.id_account, a.email, a.password_hash, r.role_name
            FROM account a
            JOIN accountrole r ON a.id_role = r.id_role";
    $stmt = getDB()->query($sql);
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Query failed: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Users</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { border: 1px solid #ddd; padding: 8px; }
    th { background: #f4f4f4; }
    .btn { padding: 6px 12px; background: #0f172a; color: #fff; text-decoration: none; border-radius: 4px; }
    .btn:hover { background: #1e293b; }
  </style>
</head>
<body>

  <h1>Manage Users</h1>
  <a href="add_user.php" class="btn">Add User</a>

  <table>
    <tr>
      <th>ID</th>
      <th>Email</th>
      <th>Password (Hash)</th>
      <th>Role</th>
      <th>Actions</th>
    </tr>
    <?php foreach ($users as $row): ?>
      <tr>
        <td><?= htmlspecialchars($row['id_account']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= htmlspecialchars($row['password_hash']) ?></td>
        <td><?= htmlspecialchars($row['role_name']) ?></td>
        <td>
          <a href="edit_user.php?id=<?= $row['id_account'] ?>">Edit</a> |
          <a href="delete_user.php?id=<?= $row['id_account'] ?>" 
             onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

</body>
</html>