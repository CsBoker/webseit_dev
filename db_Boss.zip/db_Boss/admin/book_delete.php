<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role(['admin']);

$db = DatabaseConfig::getInstance()->getConnection();
$id = intval($_GET['id']);

$stmt = $db->prepare("DELETE FROM Book WHERE id_book=?");
$stmt->execute([$id]);

header("Location: admin_dashboard.php");
exit();
