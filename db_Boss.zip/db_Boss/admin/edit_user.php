<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth.php';
require_role(['admin']);

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM account WHERE id_account = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    die("User not found!");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $role = $_POST['id_accountrole'];

    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE account SET email=?, password=?, id_accountrole=? WHERE id_account=?");
        $update->execute([$email, $password, $role, $id]);
    } else {
        $update = $pdo->prepare("UPDATE account SET email=?, id_accountrole=? WHERE id_account=?");
        $update->execute([$email, $role, $id]);
    }

    header("Location: manage_users.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit User</title></head>
<body>
  <h1>Edit User</h1>
  <form method="post">
    <label>Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required></label><br><br>
    <label>Password (leave blank to keep same): <input type="password" name="password"></label><br><br>
    <label>Role ID: <input type="number" name="id_accountrole" value="<?= htmlspecialchars($user['id_accountrole']) ?>" required></label><br><br>
    <button type="submit">Update</button>
  </form>
</body>
</html>