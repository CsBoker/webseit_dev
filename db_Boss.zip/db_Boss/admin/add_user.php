<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['id_accountrole'];

    $stmt = $pdo->prepare("INSERT INTO account (email, password, id_accountrole) VALUES (?, ?, ?)");
    $stmt->execute([$email, $password, $role]);

    header("Location: manage_users.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Add User</title></head>
<body>
  <h1>Add User</h1>
  <form method="post">
    <label>Email: <input type="email" name="email" required></label><br><br>
    <label>Password: <input type="password" name="password" required></label><br><br>
    <label>Role ID: <input type="number" name="id_accountrole" required></label><br><br>
    <button type="submit">Save</button>
  </form>
</body>
</html>