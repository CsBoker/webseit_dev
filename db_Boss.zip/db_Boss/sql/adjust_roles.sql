-- sql/adjust_roles.sql
-- Optional: ensure AccountRole contains canonical names expected by the PHP layer.
-- This is safe even if roles already exist; UNIQUE constraint recommended.
INSERT IGNORE INTO AccountRole (role_name) VALUES ('customer'), ('employee'), ('admin');

-- Map existing accounts to the closest canonical role if desired:
-- Example: Manager -> employee, Buyer/Reader -> customer
UPDATE Account a
JOIN AccountRole r_mgr ON r_mgr.role_name IN ('Manager','manager')
JOIN AccountRole r_emp ON r_emp.role_name = 'employee'
SET a.id_role = r_emp.id_role
WHERE a.id_role = r_mgr.id_role;

UPDATE Account a
JOIN AccountRole r_b ON r_b.role_name IN ('Buyer','buyer','Reader','reader')
JOIN AccountRole r_c ON r_c.role_name = 'customer'
SET a.id_role = r_c.id_role
WHERE a.id_role = r_b.id_role;
