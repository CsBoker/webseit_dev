<?php
/**
 * About page
 *
 * Provides general information about the BOSS application.  Linked from
 * the footer.  Contains static text describing the purpose of the
 * project.
 */

require_once 'config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1>About Us</h1>
                <p>Learn more about the Book Online Shop System (BOSS)</p>
            </div>
            <p>BOSS is a course project designed to demonstrate the
                development of a modern, database‑driven online book store.
                The system allows customers to browse books, manage a
                shopping cart, place orders and maintain their account
                information.  Employees and administrators can manage
                inventory, process orders and support customers.  This
                implementation serves as a learning exercise and is not
                intended for production use.</p>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>