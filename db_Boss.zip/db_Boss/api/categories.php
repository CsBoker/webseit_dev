<?php
/**
 * Categories API Endpoint
 * Handles AJAX requests for category operations
 */

require_once '../config/config.php';

header('Content-Type: application/json');

$categoryModel = new Category();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'all':
            $categories = $categoryModel->getAllCategories();
            echo json_encode(['success' => true, 'categories' => $categories]);
            break;
            
        case 'details':
            $id = (int)($_GET['id'] ?? 0);
            if ($id > 0) {
                $category = $categoryModel->getCategoryById($id);
                if ($category) {
                    echo json_encode(['success' => true, 'category' => $category]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Category not found']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid category ID']);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
