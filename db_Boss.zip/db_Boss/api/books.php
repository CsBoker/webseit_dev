<?php
/**
 * Books API Endpoint
 * Handles AJAX requests for book operations
 */

require_once '../config/config.php';

header('Content-Type: application/json');

$bookModel = new Book();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'featured':
            $books = $bookModel->getFeaturedBooks(8);
            echo json_encode(['success' => true, 'books' => $books]);
            break;
            
        case 'search':
            $query = $_GET['q'] ?? '';
            $category = $_GET['category'] ?? null;
            $limit = (int)($_GET['limit'] ?? 12);
            $offset = (int)($_GET['offset'] ?? 0);
            
            $books = $bookModel->getAllBooks($limit, $offset, $category, $query);
            $total = $bookModel->getTotalBooks($category, $query);
            
            echo json_encode([
                'success' => true, 
                'books' => $books, 
                'total' => $total,
                'hasMore' => ($offset + $limit) < $total
            ]);
            break;
            
        case 'details':
            $id = (int)($_GET['id'] ?? 0);
            if ($id > 0) {
                $book = $bookModel->getBookById($id);
                if ($book) {
                    echo json_encode(['success' => true, 'book' => $book]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Book not found']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid book ID']);
            }
            break;
            
        case 'multiple':
            $ids = $_GET['ids'] ?? '';
            if ($ids) {
                $idArray = explode(',', $ids);
                $idArray = array_map('intval', $idArray);
                $idArray = array_filter($idArray, function($id) { return $id > 0; });
                
                if (!empty($idArray)) {
                    $placeholders = str_repeat('?,', count($idArray) - 1) . '?';
                    $sql = "SELECT b.*, c.category_name, p.publisher_name,
                                   GROUP_CONCAT(CONCAT(a.first_name, ' ', a.last_name) SEPARATOR ', ') as authors
                            FROM Book b
                            LEFT JOIN Category c ON b.id_category = c.id_category
                            LEFT JOIN Publisher p ON b.id_publisher = p.id_publisher
                            LEFT JOIN Author_has_Book ab ON b.id_book = ab.id_book
                            LEFT JOIN Author a ON ab.id_author = a.id_author
                            WHERE b.id_book IN ($placeholders)
                            GROUP BY b.id_book";
                    
                    $db = DatabaseConfig::getInstance()->getConnection();
                    $stmt = $db->prepare($sql);
                    $stmt->execute($idArray);
                    $books = $stmt->fetchAll();
                    
                    echo json_encode(['success' => true, 'books' => $books]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'No valid book IDs provided']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'No book IDs provided']);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
