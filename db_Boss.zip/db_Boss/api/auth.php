<?php
/**
 * Authentication helper API
 *
 * Provides simple JSON endpoints for checking the authentication status
 * of the current session.  Used by client‑side scripts (e.g. cart.js) to
 * determine whether the user needs to login before proceeding with
 * checkout.
 */

require_once '../config/config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'check':
        $loggedIn = isLoggedIn();
        $response = ['loggedIn' => $loggedIn];
        if ($loggedIn) {
            $response['user'] = [
                'id' => $_SESSION['user_id'],
                'name' => $_SESSION['user_name'] ?? '',
                'role' => $_SESSION['user_role'] ?? ''
            ];
        }
        echo json_encode($response);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}