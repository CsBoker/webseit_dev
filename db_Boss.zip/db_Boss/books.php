<?php 
require_once 'config/config.php';

$bookModel = new Book();
$categoryModel = new Category();

// Get parameters
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$category = isset($_GET['category']) ? (int)$_GET['category'] : null;
$search = isset($_GET['search']) ? sanitize($_GET['search']) : null;
$limit = 12;
$offset = ($page - 1) * $limit;

// Get books and total count
$books = $bookModel->getAllBooks($limit, $offset, $category, $search);
$totalBooks = $bookModel->getTotalBooks($category, $search);
$totalPages = ceil($totalBooks / $limit);

// Get all categories for filter
$categories = $categoryModel->getAllCategories();

// Get current category name
$currentCategory = null;
if ($category) {
    $currentCategory = $categoryModel->getCategoryById($category);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1>
                    <?php if ($search): ?>
                        Search Results for "<?php echo htmlspecialchars($search); ?>"
                    <?php elseif ($currentCategory): ?>
                        <?php echo htmlspecialchars($currentCategory['category_name']); ?> Books
                    <?php else: ?>
                        All Books
                    <?php endif; ?>
                </h1>
                <p><?php echo $totalBooks; ?> books found</p>
            </div>

            <div class="books-layout">
                <!-- Filters Sidebar -->
                <aside class="filters-sidebar">
                    <div class="filter-section">
                        <h3>Categories</h3>
                        <ul class="category-list">
                            <li><a href="books.php" class="<?php echo !$category ? 'active' : ''; ?>">All Categories</a></li>
                            <?php foreach ($categories as $cat): ?>
                                <li>
                                    <a href="books.php?category=<?php echo $cat['id_category']; ?>" 
                                       class="<?php echo $category == $cat['id_category'] ? 'active' : ''; ?>">
                                        <?php echo htmlspecialchars($cat['category_name']); ?>
                                        <span class="count">(<?php echo $cat['book_count']; ?>)</span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </aside>

                <!-- Books Grid -->
                <div class="books-content">
                    <?php if (empty($books)): ?>
                        <div class="no-results">
                            <i class="fas fa-search"></i>
                            <h3>No books found</h3>
                            <p>Try adjusting your search criteria or browse all categories.</p>
                            <a href="books.php" class="btn">Browse All Books</a>
                        </div>
                    <?php else: ?>
                        <div class="books-grid">
                            <?php foreach ($books as $book): ?>
                               <div class="book-card">
                                    <div class="book-image">
                                        <?php 
                                        $imageFile = !empty($book['image']) ? $book['image'] : 'default.jpg';
                                        $webPath   =  "images/books/" . $imageFile;
                                        ?>
                                        <img src="<?php echo $webPath; ?>"
                                             alt="<?php echo htmlspecialchars($book['title']); ?>" 
                                             class="book-cover">
                                    </div>

                                    <div class="book-info">
                                        <h4 class="book-title"><?php echo htmlspecialchars($book['title']); ?></h4>
                                        <p class="book-author">by <?php echo htmlspecialchars($book['authors'] ?: 'Unknown Author'); ?></p>
                                        <p class="book-category"><?php echo htmlspecialchars($book['category_name']); ?></p>
                                        <p class="book-price">$<?php echo number_format($book['price'], 2); ?></p>

                                        <div class="book-actions">
                                            <form method="POST" action="add_to_cart.php" style="display:inline;">
                                                <input type="hidden" name="id_book" value="<?php echo $book['id_book']; ?>">
                                                <input type="number" name="qty" value="1" min="1" style="width:60px;">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-cart-plus"></i> Add to Cart
                                                </button>
                                            </form>
                                            <a href="book-details.php?id=<?php echo $book['id_book']; ?>" class="btn">View Details</a>
                                        </div>
                                    </div>
                               </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Pagination -->
                        <?php if ($totalPages > 1): ?>
                            <div class="pagination">
                                <?php if ($page > 1): ?>
                                    <a href="?page=<?php echo $page - 1; ?><?php echo $category ? '&category=' . $category : ''; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" class="btn">
                                        <i class="fas fa-chevron-left"></i> Previous
                                    </a>
                                <?php endif; ?>

                                <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                                    <a href="?page=<?php echo $i; ?><?php echo $category ? '&category=' . $category : ''; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" 
                                       class="btn <?php echo $i == $page ? 'active' : ''; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>

                                <?php if ($page < $totalPages): ?>
                                    <a href="?page=<?php echo $page + 1; ?><?php echo $category ? '&category=' . $category : ''; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" class="btn">
                                        Next <i class="fas fa-chevron-right"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>