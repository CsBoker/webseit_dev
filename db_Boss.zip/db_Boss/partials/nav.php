<?php  
require_once __DIR__ . '/../auth.php';  
$role = current_role();  
?>  

<nav style="display:flex;gap:12px;align-items:center;justify-content:space-between;
            padding:10px 14px;background:#0f172a;color:#fff;">  
  <div><strong>BOSS</strong> → <?= htmlspecialchars(strtoupper($role)) ?> portal</div>  
  <div style="display:flex;gap:10px;align-items:center;">  

    <!-- Customer link -->
    <a href="admin/customer_dashboard.php" style="color:#fff;">Customer</a>  

    <!-- Employee link -->
    <?php if ($role === 'employee' || $role === 'admin'): ?>  
      <a href="admin/employee_dashboard.php" style="color:#fff;">Employee</a>  
    <?php endif; ?>  

    <!-- Admin link -->
    <?php if ($role === 'admin'): ?>  
      <a href="admin/admin_dashboard.php" style="color:#fff;">Admin</a>  
      <a href="admin/manage_users.php" style="color:#fff;">Manage Users</a>  
    <?php endif; ?>  

    <!-- Logout -->
    <?php if ($role === 'admin'): ?>  
      <a href="../admin/logout.php" style="color:#fff;">Logout</a>  
    <?php else: ?>  
      <a href="../logout_rbac.php" style="color:#fff;">Logout</a>  
    <?php endif; ?>  

  </div>  
</nav>