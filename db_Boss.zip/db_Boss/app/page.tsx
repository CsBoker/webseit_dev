"use client"

import  from "../assets/js/cart"

export default function SyntheticV0PageForDeployment() {
  return < />
}